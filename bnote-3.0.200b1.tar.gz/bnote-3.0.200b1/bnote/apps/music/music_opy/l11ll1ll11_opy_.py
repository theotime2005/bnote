"""
Copyright (c)2021 eurobraille
This software is the proprietary of eurobraille and may not be copied,
distributed, published,or disclosed without express prior written permission.
"""
from .l1l1l1ll1_opy_ import *
l11lll1l11_opy_ = {l11111l111_opy_.l1l1l11ll11_opy_.c: 0, l11111l111_opy_.l1l1l11ll11_opy_.d: 2, l11111l111_opy_.l1l1l11ll11_opy_.e: 4, l11111l111_opy_.l1l1l11ll11_opy_.f: 5, l11111l111_opy_.l1l1l11ll11_opy_.g: 7, l11111l111_opy_.l1l1l11ll11_opy_.a: 9, l11111l111_opy_.l1l1l11ll11_opy_.b: 11, "no": 0}
l11ll1lll1_opy_ = {l11111l111_opy_.l1l1l11l1l1_opy_.l1l1l11llll_opy_: -2, l11111l111_opy_.l1l1l11l1l1_opy_.l1l1l11ll1l_opy_: -1, l11111l111_opy_.l1l1l11l1l1_opy_.l1l1l11l11l_opy_: 0, l11111l111_opy_.l1l1l11l1l1_opy_.l1l1l11lll1_opy_: 1, l11111l111_opy_.l1l1l11l1l1_opy_.l1l1l11l1ll_opy_: 2, "no": 0}
l11lll1l1l_opy_ = {"p" :87, "pp": 82, "ppp": 77, "pppp": 72, "ppppp": 67, "pppppp": 62, "f": 102, "ff": 107, "fff": 112, "ffff": 117, "fffff": 122, "ffffff": 127, "mp": 92, "mf": 97, "sf": 100, "sfp": 100, "sfpp": 100, "fp": 100, "rf": 100, "rfz": 100, "sfz": 100, "sffz": 100, "fz": 100, "n": 100, "pf": 100, "sfzp": 100, "other-dynamics": 100}