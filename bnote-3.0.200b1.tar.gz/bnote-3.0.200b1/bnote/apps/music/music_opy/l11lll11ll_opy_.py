"""
Copyright (c)2021 eurobraille
This software is the proprietary of eurobraille and may not be copied,
distributed, published,or disclosed without express prior written permission.
"""
class l11lllll11_opy_:
    l111l1l11l1_opy_ = True
    l11lll1ll1_opy_ = True
    l11lll11l1_opy_ = True