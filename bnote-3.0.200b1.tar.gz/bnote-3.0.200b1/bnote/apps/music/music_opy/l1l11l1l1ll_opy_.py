"""
Copyright (c)2021 eurobraille
This software is the proprietary of eurobraille and may not be copied,
distributed, published,or disclosed without express prior written permission.
"""
class l11lllll11_opy_ :
# for l1l11l11lll_opy_ to braille l1l11l1l111_opy_
    l1l11l11ll1_opy_ = True
    l1l11l11l11_opy_ = True
    l1l11l1l11l_opy_ = 5 # 0 no, 1 xml, 2 l1l11l1ll11_opy_, 3 l1l11l1l1l1_opy_, 4 xml + l1l11l1ll11_opy_, 5 xml + l1l11l1l1l1_opy_, 6 l1l11l1ll11_opy_ + l1l11l1l1l1_opy_, 7 xml + l1l11l1ll11_opy_ + l1l11l1l1l1_opy_
    l1l11l11l1l_opy_ = 6 # 0 no, 1 xml, 2 l1l11l1ll11_opy_, 3 l1l11l1l1l1_opy_, 4 xml + l1l11l1ll11_opy_, 5 xml + l1l11l1l1l1_opy_, 6 l1l11l1ll11_opy_ + l1l11l1l1l1_opy_, 7 xml + l1l11l1ll11_opy_ + l1l11l1l1l1_opy_