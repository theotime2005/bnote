python3 -m venv venv
venv/bin/pip install  --no-index --find-links ~/whl ~/bnote/bnote-3.0.0-py3-none-any.whl
