"""
Copyright (c)2021 eurobraille
This software is the proprietary of eurobraille and may not be copied,
distributed, published,or disclosed without express prior written permission.
"""
from enum import Enum, auto
from .l111l_opy_ import l1ll11_opy_
from .l11l111_opy_ import l1111111_opy_
from .l11_opy_ import l1_opy_, l11l1_opy_
from .math_exception import MathException
# l1ll_opy_ the logger for this file
from .colored_log import ColoredLogger, MATH_RESULT_LOG
log = ColoredLogger(__name__, level=MATH_RESULT_LOG)
class l11111l1_opy_(Enum):
    l1ll1lllll1_opy_ = auto()
    l111lll1l_opy_ = auto()
class l11l1ll_opy_(l1ll11_opy_):
    def __init__(self, pos, l1llll1lll_opy_=l11111l1_opy_.l111lll1l_opy_, l1lllll11l_opy_=None):
        l1ll11_opy_.__init__(self, pos)
        self.arg = l1lllll11l_opy_
        self.l1llll1lll_opy_ = l1llll1lll_opy_
    def display_tree(self, level):
        return ''.join(['    ' * level, self.l1llll1lll_opy_.name, l1ll11_opy_.display_tree(self, level), "\n",
                        self.arg.display_tree(level + 1)])
    def compute(self):
        l1llll1l11_opy_ = {
            l11111l1_opy_.l1ll1lllll1_opy_: l11l1ll_opy_.l1lllll1l1_opy_,
            l11111l1_opy_.l111lll1l_opy_: l11l1ll_opy_.l1llll11ll_opy_,
        }
        function = l1llll1l11_opy_.get(self.l1llll1lll_opy_, None)
        if function:
            return function(self)
        else:
            msg = _("function not evaluable")
            log.warning(msg)
            raise MathException(self.pos, MathException.ErrorCode.NOT_EVALUABLE, _("function not evaluable"))
    def l1lllll1l1_opy_(self):
        return self.arg.compute()
    def l1llll11ll_opy_(self):
        return -1 * self.arg.compute()