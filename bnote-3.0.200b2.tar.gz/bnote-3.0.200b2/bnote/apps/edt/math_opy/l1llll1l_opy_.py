"""
Copyright (c)2021 eurobraille
This software is the proprietary of eurobraille and may not be copied,
distributed, published,or disclosed without express prior written permission.
"""
from enum import Enum, auto
from .l111l_opy_ import l1ll11_opy_
from .l11l111_opy_ import l1111111_opy_
from .l11_opy_ import l1_opy_, l11l1_opy_
from .math_exception import MathException
# l1ll_opy_ the logger for this file
from .colored_log import ColoredLogger, MATH_RESULT_LOG
log = ColoredLogger(__name__, level=MATH_RESULT_LOG)
class l11ll1ll1_opy_(Enum):
    l1lll11ll_opy_ = auto()
    l1l1ll1l_opy_ = auto()
    l11111_opy_ = auto()
    l1llllll1l_opy_ = auto()
    l11l11l1l_opy_ = auto()
    l1llll11l1_opy_ = auto()
    l1ll1ll11_opy_ = auto()
    l11l11l1_opy_ = auto()
    l11lll11l_opy_ = auto()
    l11111l_opy_ = auto()
class l111ll111_opy_(l1ll11_opy_):
    def __init__(self, pos, l1llll1lll_opy_=l11ll1ll1_opy_.l1l1ll1l_opy_, l1lllll11l_opy_=None, l1lllllll1_opy_=None):
        l1ll11_opy_.__init__(self, pos)
        self.l1lllll111_opy_ = l1lllll11l_opy_
        self.l1llll111l_opy_ = l1lllllll1_opy_
        self.l1llll1lll_opy_ = l1llll1lll_opy_
    def display_tree(self, level):
        return ''.join(['    ' * level, self.l1llll1lll_opy_.name, l1ll11_opy_.display_tree(self, level), "\n",
                        self.l1lllll111_opy_.display_tree(level + 1),
                        self.l1llll111l_opy_.display_tree(level + 1)])
    def compute(self):
        l1llll1l11_opy_ = {
            l11ll1ll1_opy_.l1lll11ll_opy_: l111ll111_opy_.l1lllll1l1_opy_,
            l11ll1ll1_opy_.l1l1ll1l_opy_: l111ll111_opy_.l1llll11ll_opy_,
            l11ll1ll1_opy_.l11111_opy_: l111ll111_opy_.l1llll1111_opy_,
            l11ll1ll1_opy_.l1llllll1l_opy_: l111ll111_opy_.l1llll1111_opy_,
            l11ll1ll1_opy_.l11l11l1l_opy_: l111ll111_opy_.l1lllll1ll_opy_,
            l11ll1ll1_opy_.l1llll11l1_opy_: l111ll111_opy_.l1lllll1ll_opy_,
            l11ll1ll1_opy_.l1ll1ll11_opy_: l111ll111_opy_.l1llllll11_opy_,
            l11ll1ll1_opy_.l11l11l1_opy_: l111ll111_opy_.l1llll1ll1_opy_,
            l11ll1ll1_opy_.l11lll11l_opy_: l111ll111_opy_.l1lll1lll1_opy_,
            l11ll1ll1_opy_.l11111l_opy_: l111ll111_opy_.l1lll1ll1l_opy_,
        }
        function = l1llll1l11_opy_.get(self.l1llll1lll_opy_, None)
        if function:
            return function(self)
        else:
            msg = _("function not evaluable")
            log.warning(msg)
            raise MathException(self.pos, MathException.ErrorCode.NOT_EVALUABLE, _("function not evaluable"))
    def l1lllll1l1_opy_(self):
        return self.l1lllll111_opy_.compute() + self.l1llll111l_opy_.compute()
    def l1llll11ll_opy_(self):
        return self.l1lllll111_opy_.compute() - self.l1llll111l_opy_.compute()
    def l1llll1111_opy_(self):
        return self.l1lllll111_opy_.compute() * self.l1llll111l_opy_.compute()
    def l1lllll1ll_opy_(self):
        try:
            return self.l1lllll111_opy_.compute() / self.l1llll111l_opy_.compute()
        except ZeroDivisionError:
            raise MathException(self.pos, MathException.ErrorCode.DIVISION_BY_ZERO, _("division by zero"))
    def l1llllll11_opy_(self):
        value = self.l1llll111l_opy_.compute()
        if not isinstance(self.l1lllll111_opy_, l1111111_opy_):
            raise MathException(self.pos, MathException.ErrorCode.INVALID_ASSIGNMENT, _("assignment must be only into parameter"))
        else:
            l11l1_opy_.l1ll1_opy_(self.l1lllll111_opy_.l1llllllll_opy_, value)
        return value
    def l1llll1ll1_opy_(self):
        value = self.l1llll111l_opy_.compute()
        l1lll1llll_opy_ = self.l1lllll111_opy_.compute()
        l1llll1l1l_opy_ = int(l1lll1llll_opy_ // 1)
        if l1llll1l1l_opy_ == l1lll1llll_opy_:
            return [value] * l1llll1l1l_opy_
        else:
            raise MathException(self.pos, MathException.ErrorCode.INVALID_ARG, _("weighted arithmetic mean invalid"))
    def l1lll1lll1_opy_(self):
        return self.l1lllll111_opy_.compute() % self.l1llll111l_opy_.compute()
    def l1lll1ll1l_opy_(self):
        return self.l1lllll111_opy_.compute() ** int(self.l1llll111l_opy_.compute())