"""
Copyright (c)2021 eurobraille
This software is the proprietary of eurobraille and may not be copied,
distributed, published,or disclosed without express prior written permission.
"""
import xml.etree.ElementTree as l11111l1l_opy_
from xml.dom import minidom
from .l1l1ll1lll_opy_ import *
class l1l11l111_opy_:
    def __init__ (self, l1l1l1l1ll_opy_, l1l1ll11l1_opy_, l1ll1111l_opy_):
        self._1l1l11ll_opy_ = l1l1l1l1ll_opy_
        self._1l111l11_opy_ = l1l1ll11l1_opy_
        self._1lll1111_opy_ = l1ll1111l_opy_
    def create_file(self):
        self._1l111l11_opy_("\nmodel to xml\n")
        root = l11111l1l_opy_.Element("score-partwise")
        root.attrib = {"version":"2.0"}
        l11l1l1l1_opy_ = l11111l1l_opy_.SubElement(root, "defaults")
        l1lll1llll_opy_ = l11111l1l_opy_.SubElement(l11l1l1l1_opy_, "lyric-font")
        l1lll1llll_opy_.attrib = {"font-family": "Times New Roman"}
        for element in self._1lll1111_opy_.l111l11l1_opy_:
            if element.t == "credit":
                l1l1lll11l_opy_ = l11111l1l_opy_.SubElement(root, "credit")
                l1l1lll11l_opy_.attrib = {"page":"1"}
                if element.l1l11l111l_opy_ !="no":
                    l1ll1l111l_opy_ = l11111l1l_opy_.SubElement(l1l1lll11l_opy_, "credit-type").text = element.l1l11l111l_opy_
                l1lllll1ll_opy_ = l11111l1l_opy_.SubElement(l1l1lll11l_opy_, "credit-words").text = element.l1111l11l_opy_
            if element.t == "part-list":
                l111lll11_opy_ = l11111l1l_opy_.SubElement(root, "part-list")
                for l1lll1l1l1_opy_ in element.l1ll1lll1l_opy_:
                    l111l1lll_opy_ = l11111l1l_opy_.SubElement(l111lll11_opy_, "score-part")
                    if l1lll1l1l1_opy_.l1l1l111ll_opy_ != "no":
                        l111l1lll_opy_.attrib = {"id":l1lll1l1l1_opy_.l1l1l111ll_opy_}
                    if l1lll1l1l1_opy_.l1lll11l1l_opy_ != "no":
                        l1ll1l1lll_opy_ = l11111l1l_opy_.SubElement(l111l1lll_opy_, "part-name").text = l1lll1l1l1_opy_.l1lll11l1l_opy_
                    if l1lll1l1l1_opy_.l1lll111l1_opy_ != "no":
                        l1l11l11ll_opy_ = l11111l1l_opy_.SubElement(l111l1lll_opy_, "part-abbreviation").text = l1lll1l1l1_opy_.l1lll111l1_opy_
                    if l1lll1l1l1_opy_.l1ll111l11_opy_ != "no":
                        l1l1l11lll_opy_ = l11111l1l_opy_.SubElement(l111l1lll_opy_, "score-instrument")
                        l1l1l11lll_opy_.attrib = {"id":l1lll1l1l1_opy_.l1ll111l11_opy_}
                    if l1lll1l1l1_opy_.l111ll1ll_opy_ != "no":
                        l1111llll_opy_ = l11111l1l_opy_.SubElement(l1l1l11lll_opy_, "instrument-name").text = l1lll1l1l1_opy_.l111ll1ll_opy_
                    if l1lll1l1l1_opy_.l1ll111111_opy_ != "no" or l1lll1l1l1_opy_.l1lll1lll1_opy_ != "no":
                        l1ll1ll11l_opy_ = l11111l1l_opy_.SubElement(l111l1lll_opy_, "midi-device")
                        l1ll1ll11l_opy_.attrib = {"id":l1lll1l1l1_opy_.l1ll111111_opy_, "port":l1lll1l1l1_opy_.l1lll1lll1_opy_}
                    if l1lll1l1l1_opy_.l1l1ll111l_opy_ != "no":
                        l111ll111_opy_ = l11111l1l_opy_.SubElement(l111l1lll_opy_, "midi-instrument")
                        l111ll111_opy_.attrib = {"id":l1lll1l1l1_opy_.l1l1ll111l_opy_}
                    if l1lll1l1l1_opy_.l1lll11ll1_opy_ != "no":
                        l11ll11l1_opy_ = l11111l1l_opy_.SubElement(l111ll111_opy_, "midi-channel").text = l1lll1l1l1_opy_.l1lll11ll1_opy_
                    if l1lll1l1l1_opy_.l1ll1111ll_opy_ != "no":
                        l11ll1lll_opy_ = l11111l1l_opy_.SubElement(l111ll111_opy_, "midi-program").text = l1lll1l1l1_opy_.l1ll1111ll_opy_
                    if l1lll1l1l1_opy_.l1l1lll111_opy_ != "no":
                        l11l1l11l_opy_ = l11111l1l_opy_.SubElement(l111ll111_opy_, "volume").text = l1lll1l1l1_opy_.l1l1lll111_opy_
                    if l1lll1l1l1_opy_.l1l1ll1l1l_opy_ != "no":
                        l11111l11_opy_ = l11111l1l_opy_.SubElement(l111ll111_opy_, "pan").text = l1lll1l1l1_opy_.l1l1ll1l1l_opy_
            if element.t == "part":
                l1ll1l1111_opy_ = l11111l1l_opy_.SubElement(root, "part")
                l1ll1l1111_opy_.attrib = {"id":element.l1l1l111ll_opy_}
                for l1ll111ll1_opy_ in element.l11lll1ll_opy_:
                    l1ll1lllll_opy_ = l11111l1l_opy_.SubElement(l1ll1l1111_opy_, "measure")
                    l1ll1lllll_opy_.attrib = {"number":str(l1ll111ll1_opy_.l1ll11l11l_opy_)}
                    l1l111lll1_opy_ = False
                    l11ll1l1l_opy_ = False
                    l1l11lllll_opy_ = False
                    l1l11111l1_opy_ = False
                    l11lll111_opy_ = False
                    l1ll1l1l11_opy_ = False
                    for event in l1ll111ll1_opy_.l1ll11l1l1_opy_:
                        l1llll1ll1_opy_ = False
                        if event.t == "attributes":
# l11l11111_opy_ l11ll11ll_opy_ l1l1l11l1l_opy_ element to be l1ll11lll1_opy_ to l1l111llll_opy_ l111l111l_opy_ in the l1l1ll1l11_opy_ order
                            for l1ll1ll1l1_opy_ in event.l1l1ll11ll_opy_:
                                if l1ll1ll1l1_opy_.t == "divisions":
                                    l1l111lll1_opy_ = True
                                    l1l1111l11_opy_ = str(l1ll1ll1l1_opy_.l1lllll11l_opy_)
                                if l1ll1ll1l1_opy_.t == "key":
                                    l11ll1l1l_opy_ = True
                                    l1ll11ll1l_opy_ = str(l1ll1ll1l1_opy_.l11l1ll1l_opy_)
                                    l1111l1ll_opy_ = l1ll1ll1l1_opy_.mode
                                if l1ll1ll1l1_opy_.t == "time":
                                    l1l11lllll_opy_ = True
                                    l1l1l1l11l_opy_ = l1ll1ll1l1_opy_.l1l1llll11_opy_
                                    l1l11lll1l_opy_ = l1ll1ll1l1_opy_.l1lllll111_opy_
                                    l1l111ll11_opy_ = l1ll1ll1l1_opy_.l1lll11111_opy_
                                if l1ll1ll1l1_opy_.t == "staves":
                                    l1l11111l1_opy_ = True
                                    l1llllllll_opy_ = l1ll1ll1l1_opy_.l1111ll11_opy_
                                if l1ll1ll1l1_opy_.t == "clef":
                                    l11lll111_opy_ = True
                                    l1l11lll11_opy_ = l1ll1ll1l1_opy_.sign
                                    l11l1llll_opy_ = l1ll1ll1l1_opy_.line
                                    l1l111l111_opy_ = l1ll1ll1l1_opy_.l1llll11ll_opy_
                        else:
# l1l111llll_opy_ l1ll11l111_opy_ to have l11111ll1_opy_ in the l1l1ll1l11_opy_ order for l111l111l_opy_
                            if l1l111lll1_opy_ or l11ll1l1l_opy_ or l1l11lllll_opy_ or l1l11111l1_opy_ or l11lll111_opy_:
                                l1lll1l11l_opy_ = l11111l1l_opy_.SubElement(l1ll1lllll_opy_, "attributes")
                                if l1l111lll1_opy_:
                                    l1l1111ll_opy_ = l11111l1l_opy_.SubElement(l1lll1l11l_opy_, "divisions").text = l1l1111l11_opy_
                                    l1l111lll1_opy_ = False
                                if l11ll1l1l_opy_:
                                    l11lll1l1_opy_ = l11111l1l_opy_.SubElement(l1lll1l11l_opy_, "key")
                                    l111llll1_opy_ = l11111l1l_opy_.SubElement(l11lll1l1_opy_, "fifths").text = l1ll11ll1l_opy_
                                    if l1111l1ll_opy_ !="no":
                                        l1ll111l1l_opy_ = l11111l1l_opy_.SubElement(l11lll1l1_opy_, "mode").text = l1111l1ll_opy_
                                    l11ll1l1l_opy_ = False
                                if l1l11lllll_opy_:
                                    l1l1111ll1_opy_ = l11111l1l_opy_.SubElement(l1lll1l11l_opy_, "time")
                                    l1lll1l111_opy_ = l11111l1l_opy_.SubElement(l1l1111ll1_opy_, "beats").text = l1l1l1l11l_opy_
                                    l1llll1lll_opy_ = l11111l1l_opy_.SubElement(l1l1111ll1_opy_, "beat-type").text = l1l11lll1l_opy_
                                    if l1l111ll11_opy_ != "no":
                                        l1l1111ll1_opy_.attrib = {"symbol":l1l111ll11_opy_}
                                    l1l11lllll_opy_ = False
                                if l1l11111l1_opy_:
                                    l1l1l11l11_opy_ = l11111l1l_opy_.SubElement(l1lll1l11l_opy_, "staves").text = l1llllllll_opy_
                                    l1l11111l1_opy_ = False
                                if l11lll111_opy_:
                                    l1lll11lll_opy_ = l11111l1l_opy_.SubElement(l1lll1l11l_opy_, "clef")
                                    l11l1l1ll_opy_ = l11111l1l_opy_.SubElement(l1lll11lll_opy_, "sign").text = l1l11lll11_opy_
                                    l1lll11l11_opy_ = l11111l1l_opy_.SubElement(l1lll11lll_opy_, "line").text = l11l1llll_opy_
                                    if l1l111l111_opy_ !="no":
                                        l1l1l1ll1l_opy_ = l11111l1l_opy_.SubElement(l1lll11lll_opy_, "clef-octave-change").text = l1l111l111_opy_
                                    l11lll111_opy_ = False
                        if event.t == "note":
                            l1l1111lll_opy_ = False
                            l11llll1l_opy_ = l11111l1l_opy_.SubElement(l1ll1lllll_opy_, "note")
                            if event.l1111111l_opy_:
                                l1l11llll1_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "grace")
                            if event.l1l11l1l11_opy_:
                                l1l11llll1_opy_.attrib = {"slash":"yes"}
                            if event.l1l11l1l11_opy_ == "no":
                                l1l11llll1_opy_.attrib = {"slash":"no"}
                            if event.l11111111_opy_:
                                l1lllllll1_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "chord")
                            if event.step !="no":
                                l1l11111ll_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "pitch")
                                l11ll111l_opy_ = l11111l1l_opy_.SubElement(l1l11111ll_opy_, "step").text = l1ll11ll11_opy_[event.step]
                            if event.l1llll1l1l_opy_ !="no":
                                l1111lll1_opy_ = l11111l1l_opy_.SubElement(l1l11111ll_opy_, "alter").text = l1ll111lll_opy_[event.l1llll1l1l_opy_]
                            if event.l111l11ll_opy_ !=100:
                                l11l111l1_opy_ = l11111l1l_opy_.SubElement(l1l11111ll_opy_, "octave").text = str(event.l111l11ll_opy_)
                            if event.rest:
                                l1ll11111l_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "rest")
                            if event.l1l1lll1l1_opy_ != 0:
                                l111l1111_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "duration").text = str(event.l1l1lll1l1_opy_)
                            if event.l1l1llllll_opy_:
                                l111lll1l_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "tie")
                                if event.l1ll1llll1_opy_ !="no":
                                    l111lll1l_opy_.attrib = {"type":event.l1ll1llll1_opy_}
                            if event.l1ll1l11ll_opy_ != 0:
                                l1ll1l1ll1_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "voice").text = str(event.l1ll1l11ll_opy_)
                            if event.type !="no":
                                l1ll1ll111_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "type").text = l1l1ll1111_opy_[event.type]
                            if event.dot:
                                l11l1111l_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "dot")
                            if event.l111l1ll1_opy_ != "no":
                                l1lll1ll11_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "accidental").text = event.l111l1ll1_opy_
                            if event.l1ll1lll11_opy_ !=0 and event.l111l1l11_opy_ != 0:
                                l1l111l11l_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "time-modification")
                                l111111ll_opy_ = l11111l1l_opy_.SubElement(l1l111l11l_opy_, "actual-notes").text = str(event._11llllll_opy_)
                                l1ll1111l1_opy_ = l11111l1l_opy_.SubElement(l1l111l11l_opy_, "normal-notes").text = str(event._1ll11l1ll_opy_)
                            if event.l1111l111_opy_ !="no":
                                l11l1ll11_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "staff").text = str(event.l1111l111_opy_)
                            if event.l1l1llllll_opy_:
                                if not l1l1111lll_opy_:
                                    l1l111111l_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "notations")
                                    l1l1111lll_opy_ = True
                                l11ll1111_opy_ = l11111l1l_opy_.SubElement(l1l111111l_opy_, "tied")
                                if event.l1ll1llll1_opy_ !="no":
                                    l11ll1111_opy_.attrib = {"type":event.l1ll1llll1_opy_}
                            if event.l1l11l1ll1_opy_:
                                if not l1l1111lll_opy_:
                                    l1l111111l_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "notations")
                                    l1l1111lll_opy_ = True
                                l111l1l1l_opy_ = l11111l1l_opy_.SubElement(l1l111111l_opy_, "slur")
                                if event.l1ll1l1l1l_opy_ !="no":
                                    l111l1l1l_opy_.attrib = {"type":event.l1ll1l1l1l_opy_}
                                if event.l111lllll_opy_ !="no":
                                    l111l1l1l_opy_.attrib.update ({"number":event.l111lllll_opy_})
                                if event.l11l1l111_opy_ !="no":
                                    l111l1l1l_opy_.attrib.update ({"placement":event.l11l1l111_opy_})
                            if event.l1l1l1111l_opy_:
                                if not l1l1111lll_opy_:
                                    l1l111111l_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "notations")
                                    l1l1111lll_opy_ = True
                                l111l1l1l_opy_ = l11111l1l_opy_.SubElement(l1l111111l_opy_, "slur")
                                if event.l1ll1ll1ll_opy_ !="no":
                                    l111l1l1l_opy_.attrib = {"type":event.l1ll1ll1ll_opy_}
                                if event.l1l1lll1ll_opy_ !="no":
                                    l111l1l1l_opy_.attrib.update ({"number":event.l1l1lll1ll_opy_})
                                if event.l1lll111ll_opy_ !="no":
                                    l111l1l1l_opy_.attrib.update ({"placement":event.l1lll111ll_opy_})
                            if event.l1llllll1l_opy_ !="no":
                                if not l1l1111lll_opy_:
                                    l1l111111l_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "notations")
                                    l1l1111lll_opy_ = True
                                l1llll1l11_opy_ = l11111l1l_opy_.SubElement(l1l111111l_opy_, "technical")
                                l11l11ll1_opy_ = l11111l1l_opy_.SubElement(l1llll1l11_opy_, "fingering").text = event.l1llllll1l_opy_
                            if event.l1lll1ll1l_opy_:
                                if not l1l1111lll_opy_:
                                    l1l111111l_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "notations")
                                    l1l1111lll_opy_ = True
                                l1l1l1l111_opy_ = l11111l1l_opy_.SubElement(l1l111111l_opy_, "articulations")
                                l111ll11l_opy_ = l11111l1l_opy_.SubElement(l1l1l1l111_opy_, "staccato")
                            if event.l1l111ll1l_opy_:
                                if not l1l1111lll_opy_:
                                    l1l111111l_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "notations")
                                    l1l1111lll_opy_ = True
                                l1l1l1l111_opy_ = l11111l1l_opy_.SubElement(l1l111111l_opy_, "articulations")
                                l11lllll1_opy_ = l11111l1l_opy_.SubElement(l1l1l1l111_opy_, "staccatissimo")
                            if event.l1llll11l1_opy_:
                                if not l1l1111lll_opy_:
                                    l1l111111l_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "notations")
                                    l1l1111lll_opy_ = True
                                l1l1l1l111_opy_ = l11111l1l_opy_.SubElement(l1l111111l_opy_, "articulations")
                                l1l11l1lll_opy_ = l11111l1l_opy_.SubElement(l1l1l1l111_opy_, "accent")
                            if event.l1l11ll1l1_opy_:
                                if not l1l1111lll_opy_:
                                    l1l111111l_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "notations")
                                    l1l1111lll_opy_ = True
                                l1l1l1l111_opy_ = l11111l1l_opy_.SubElement(l1l111111l_opy_, "articulations")
                                l1lllll1l1_opy_ = l11111l1l_opy_.SubElement(l1l1l1l111_opy_, "breath-mark")
                            if event.l1l1l11111_opy_:
                                if not l1l1111lll_opy_:
                                    l1l111111l_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "notations")
                                    l1l1111lll_opy_ = True
                                l1l1l1l1l1_opy_ = l11111l1l_opy_.SubElement(l1l111111l_opy_, "fermata")
                            if event.l1111l1l1_opy_:
                                if not l1l1111lll_opy_:
                                    l1l111111l_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "notations")
                                    l1l1111lll_opy_ = True
                                l11l11l11_opy_ = l11111l1l_opy_.SubElement(l1l111111l_opy_, "ornaments")
                                l111111l1_opy_ = l11111l1l_opy_.SubElement(l11l11l11_opy_, "trill-mark")
                            if event.text != "":
                                l1ll11llll_opy_ = l11111l1l_opy_.SubElement(l11llll1l_opy_, "lyric")
                                l11111lll_opy_ = l11111l1l_opy_.SubElement(l1ll11llll_opy_, "syllabic").text = event._11l11l1l_opy_
                                l111ll1l1_opy_ = l11111l1l_opy_.SubElement(l1ll11llll_opy_, "text").text = event.text
                        if event.t == "direction":
                            l1llllll11_opy_ = l11111l1l_opy_.SubElement(l1ll1lllll_opy_, "direction")
                            if event.l1l1111l1l_opy_ != "no":
                                l1llllll11_opy_.attrib = {"placement":event.l1l1111l1l_opy_}
                            for l1ll1ll1l1_opy_ in event.l1l1l1lll1_opy_:
                                if l1ll1ll1l1_opy_.t == "dynamics":
                                    l1llll1111_opy_ = l11111l1l_opy_.SubElement(l1llllll11_opy_, "direction-type")
                                    l1l11ll11l_opy_ = l11111l1l_opy_.SubElement(l1llll1111_opy_, "dynamics")
                                    l1l1111111_opy_ = l11111l1l_opy_.SubElement(l1l11ll11l_opy_, l1ll1ll1l1_opy_.l1l1l111l1_opy_)
                                if l1ll1ll1l1_opy_.t == "pedal":
                                    l1llll1111_opy_ = l11111l1l_opy_.SubElement(l1llllll11_opy_, "direction-type")
                                    l1l1llll1l_opy_ = l11111l1l_opy_.SubElement(l1llll1111_opy_, "pedal")
                                    l1l1llll1l_opy_.attrib = {"type":l1ll1ll1l1_opy_.l1l1l1llll_opy_}
                                if l1ll1ll1l1_opy_.t == "wedge":
                                    l1llll1111_opy_ = l11111l1l_opy_.SubElement(l1llllll11_opy_, "direction-type")
                                    l1l11ll1ll_opy_ = l11111l1l_opy_.SubElement(l1llll1111_opy_, "wedge")
                                    l1l11ll1ll_opy_.attrib = {"type":l1ll1ll1l1_opy_.l1l11111l_opy_}
                                if l1ll1ll1l1_opy_.t == "metronome":
                                    l1llll1111_opy_ = l11111l1l_opy_.SubElement(l1llllll11_opy_, "direction-type")
                                    l1l111l1ll_opy_ = l11111l1l_opy_.SubElement(l1llll1111_opy_, "metronome")
                                    if l1ll1ll1l1_opy_.l1l11l1l1l_opy_ != "no":
                                        l1l1111l1_opy_ = l11111l1l_opy_.SubElement(l1l111l1ll_opy_, "beat-unit").text = l1ll1ll1l1_opy_.l1l11l1l1l_opy_
                                    if l1ll1ll1l1_opy_.l1l11ll111_opy_:
                                        l1l1111l1_opy_ = l11111l1l_opy_.SubElement(l1l111l1ll_opy_, "beat-unit-dot")
                                    if l1ll1ll1l1_opy_.l1l1l11ll1_opy_ != "no":
                                        l1lll1111l_opy_ = l11111l1l_opy_.SubElement(l1l111l1ll_opy_, "per-minute").text = l1ll1ll1l1_opy_.l1l1l11ll1_opy_
                                if l1ll1ll1l1_opy_.t == "sound":
                                    l1l1lllll1_opy_ = l11111l1l_opy_.SubElement(l1llllll11_opy_, "sound")
                                    if l1ll1ll1l1_opy_.l1l111l1l1_opy_ != "no":
                                        l1l1lllll1_opy_.attrib = {"tempo":l1ll1ll1l1_opy_.l1l111l1l1_opy_}
                                    if l1ll1ll1l1_opy_.l1l1ll1ll1_opy_ != "no":
                                        l1l1lllll1_opy_.attrib = {"tempo":l1ll1ll1l1_opy_.l1l1ll1ll1_opy_}
                                if l1ll1ll1l1_opy_.t == "words":
                                    l1llll1111_opy_ = l11111l1l_opy_.SubElement(l1llllll11_opy_, "direction-type")
                                    l1llll111l_opy_ = l11111l1l_opy_.SubElement(l1llll1111_opy_, "words").text = l1ll1ll1l1_opy_.words
                            if event.l1111l111_opy_ != 1:
                                l1l1l1ll11_opy_ = l11111l1l_opy_.SubElement(l1llllll11_opy_, "staff").text = str(event.l1111l111_opy_)
                        if event.t == "backup":
                            l11ll1l11_opy_ = l11111l1l_opy_.SubElement(l1ll1lllll_opy_, "backup")
                            l111l1111_opy_ = l11111l1l_opy_.SubElement(l11ll1l11_opy_, "duration").text = str(event.l1l1lll1l1_opy_)
                        if event.t == "barline":
                            l1111ll1l_opy_ = l11111l1l_opy_.SubElement(l1ll1lllll_opy_, "barline")
                            if event.location != "no":
                                l1111ll1l_opy_.attrib = {"location":event.location}
                            if event.l1lll1l1ll_opy_ != "no":
                                l11l1lll1_opy_ = l11111l1l_opy_.SubElement(l1111ll1l_opy_, "bar-style").text = event.l1lll1l1ll_opy_
                            if event.l11l11lll_opy_ != "no":
                                l11lll11l_opy_ = l11111l1l_opy_.SubElement(l1111ll1l_opy_, "repeat")
                                l11lll11l_opy_.attrib = {"direction":event.l11l11lll_opy_}
                        if event.t == "print":
                            l11llll11_opy_ = l11111l1l_opy_.SubElement(l1ll1lllll_opy_, "print")
                            if event.l1ll1l11l1_opy_ != "no":
                                l11llll11_opy_.attrib = {"new-system":event.l1ll1l11l1_opy_}
        l11ll1ll1_opy_ = minidom.parseString(l11111l1l_opy_.tostring(root)).toprettyxml(indent="   ", encoding="UTF-8", standalone="")
#        self._1l111l11_opy_ (l11ll1ll1_opy_)
        self._1l1l11ll_opy_ (l11ll1ll1_opy_)