"""
Copyright (c)2021 eurobraille
This software is the proprietary of eurobraille and may not be copied,
distributed, published,or disclosed without express prior written permission.
"""
class l1l1l1l11l1_opy_ :
    l1l1l1l1l11_opy_ = True