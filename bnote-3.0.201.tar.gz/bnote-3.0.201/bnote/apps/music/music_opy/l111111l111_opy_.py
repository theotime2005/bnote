"""
Copyright (c)2021 eurobraille
This software is the proprietary of eurobraille and may not be copied,
distributed, published,or disclosed without express prior written permission.
"""


class l111111l11l_opy_:
    l1111111lll_opy_ = True
