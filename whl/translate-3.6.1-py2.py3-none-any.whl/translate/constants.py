CONFIG_FILE_PATH = '~/.python-translate.cfg'
DEFAULT_PROVIDER = 'mymemory'
TRANSLATION_FROM_DEFAULT = 'autodetect'
