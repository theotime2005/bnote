"""
Copyright (c)2021 eurobraille
This software is the proprietary of eurobraille and may not be copied,
distributed, published,or disclosed without express prior written permission.
"""
from .l111l_opy_ import l1ll11_opy_
from .math_exception import MathException
# l1ll_opy_ the logger for this file
from .colored_log import ColoredLogger, MATH_RESULT_LOG
log = ColoredLogger(__name__, level=MATH_RESULT_LOG)
class l1lll1_opy_(l1ll11_opy_):
    def __init__(self, pos, l1llll_opy_=[]):
        l1ll11_opy_.__init__(self, pos)
        self.l1llll_opy_ = l1llll_opy_
    def display_tree(self, level):
        text = ''.join(['    ' * level, "MULTI OPERAND", l1ll11_opy_.display_tree(self, level), "\n"])
        for l1111_opy_ in self.l1llll_opy_:
            op = l1111_opy_.display_tree(level + 1)
            text = ''.join([text, op])
        return text
    def compute(self):
        values = list()
        for l1111_opy_ in self.l1llll_opy_:
            values.append(l1111_opy_.compute())
        return values