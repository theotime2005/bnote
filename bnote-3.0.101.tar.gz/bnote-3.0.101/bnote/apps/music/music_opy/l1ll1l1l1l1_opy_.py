"""
Copyright (c)2021 eurobraille
This software is the proprietary of eurobraille and may not be copied,
distributed, published,or disclosed without express prior written permission.
"""
import os
import xml.sax
from .l1l1l1ll1_opy_ import *
class l1ll1ll1ll1_opy_:
    def __init__(self, lou, l1l1ll1ll_opy_, l1l1l11l1_opy_):
        self.lou = lou
        self._1ll11111_opy_ = l1l1ll1ll_opy_
        self.l1l1l11l1_opy_ = l1l1l11l1_opy_
    class l1lll11111l_opy_(xml.sax.ContentHandler):
        l1lll1l11l1_opy_ = "measure"
        l1llll1l1l1_opy_ = "note"
        l11l1l1l1l_opy_ = "chord"
        l1ll11ll111_opy_ = "grace"
        l1ll1111l1l_opy_ = "rest"
        l1lllll1lll_opy_ = "step"
        l111l1l1l1_opy_ = "alter"
        l1l1ll1l111_opy_ = "accidental"
        l11111llll_opy_ = "octave"
        l1lll1llll1_opy_ = "duration"
        l1ll1l11l1l_opy_ = "voice"
        l1l1ll11lll_opy_ = "type"
        l1l1ll111l1_opy_ = "dot"
        l1llllll111_opy_ = "staff"
        l11l11111l_opy_ = "slur"
        l11111111l_opy_ = "credit"
        l1ll1lll111_opy_ = "credit-type"
        l11ll111l1_opy_ = "credit-words"
        l1l1lllllll_opy_ = "score-part"
        l111lll111_opy_ = "part-name"
        l1111llll1_opy_ = "part-abbreviation"
        l1llll1ll1l_opy_ = "score-instrument"
        l1ll1l111l1_opy_ = "instrument-name"
        l1111ll11l_opy_ = "midi-device"
        l11l1ll1ll_opy_ = "midi-instrument"
        l1ll1ll11ll_opy_ = "midi-channel"
        l1lll111111_opy_ = "midi-program"
        l11111ll11_opy_ = "volume"
        l1lll1ll11l_opy_ = "pan"
        l1lllll11ll_opy_ = "part-list"
        l111l1l1ll_opy_ = "part"
        l111ll1lll_opy_ = "attributes"
        l1ll1111l11_opy_ = "divisions"
        l1ll1111lll_opy_ = "key"
        l111l111l1_opy_ = "fifths"
        l11l11lll1_opy_ = "mode"
        l111l1l11l_opy_ = "time"
        l1111l1l11_opy_ = "beats"
        l11ll11l11_opy_ = "beat-type"
        l111lll11l_opy_ = "staves"
        l1ll111ll1l_opy_ = "clef"
        l1ll11l111l_opy_ = "sign"
        l1lll11l1ll_opy_ = "line"
        l111l1l111_opy_ = "clef-octave-change"
        l1ll1l1111l_opy_ = "metronome"
        l1ll1l1l1ll_opy_ = "beat-unit"
        l1ll1l1lll1_opy_ = "beat-unit-dot"
        l11l1l111l_opy_ = "per-minute"
        l111ll111l_opy_ = "fingering"
        l11l1111l1_opy_ = "backup"
        l1llll1llll_opy_ = "direction"
        l11l1111ll_opy_ = "p"
        l1ll11lll1l_opy_ = "pp"
        l111l11l11_opy_ = "ppp"
        l1111lll11_opy_ = "pppp"
        l111l11lll_opy_ = "ppppp"
        l1ll111l11l_opy_ = "pppppp"
        l111l1lll1_opy_ = "f"
        l11l1l1ll1_opy_ = "ff"
        l111111111_opy_ = "fff"
        l1lll11ll1l_opy_ = "ffff"
        l1ll11ll11l_opy_ = "fffff"
        l1llll1ll11_opy_ = "ffffff"
        l1lll1l1111_opy_ = "mp"
        l111l1ll1l_opy_ = "mf"
        l1111lllll_opy_ = "sf"
        l1111ll1l1_opy_ = "sfp"
        l1lllll1l11_opy_ = "sfpp"
        l1l1ll1lll1_opy_ = "fp"
        l1ll11l1ll1_opy_ = "rf"
        l1l1lll1l11_opy_ = "rfz"
        l11l11l111_opy_ = "sfz"
        l1ll1ll111l_opy_ = "sffz"
        l11l111111_opy_ = "fz"
        N = "n"
        l1l1ll1l1l1_opy_ = "pf"
        l1lll1l11ll_opy_ = "sfzp"
        l111llll1l_opy_ = "other-dynamics"
        l1ll111lll1_opy_ = "words"
        l1ll1l1l11l_opy_ = "actual-notes"
        l1l1lll1lll_opy_ = "normal-notes"
        l1lllll1ll1_opy_ = "print"
        l1ll11lllll_opy_ = "staff-layout"
        l1ll111111l_opy_ = "lyric"
        l1111111ll_opy_ = "syllabic"
        l1ll111l1l1_opy_ = "text"
        l1ll1ll11l1_opy_ = "tie"
        l1111ll111_opy_ = "barline"
        l111l11l1l_opy_ = "bar-style"
        REPEAT = "repeat"
        l11l1ll11l_opy_ = "ending"
        l111l111ll_opy_ = "staccato"
        l1l1lll11ll_opy_ = "staccatissimo"
        l1ll1llll11_opy_ = "accent"
        l1llll1111l_opy_ = "breath-mark"
        l1111l111l_opy_ = "fermata"
        l1ll111l111_opy_ = "trill-mark"
        l1llll11ll1_opy_ = "pedal"
        l111l1llll_opy_ = "wedge"
        l1ll11ll1ll_opy_ = "sound"
        def __init__(self, l1l1l1l1ll_opy_, l1ll1111l_opy_, l1ll1llllll_opy_):
            self.l1ll1111l_opy_ = l1ll1111l_opy_
            self._111l11ll1_opy_ = l1ll1llllll_opy_
            self._1llll1l111_opy_ = 1
            self.l1ll11l11l1_opy_ = False
            self.l1llllll1ll_opy_ = False
            self.l1lll1ll1l1_opy_ = False
            self.l1ll1l111ll_opy_ = False
            self.l11l1l1l11_opy_ = False
            self.l1l1ll1llll_opy_ = False
            self.l1111l1ll1_opy_ = False
            self.l11l1lllll_opy_ = False
            self.l1ll1lllll1_opy_ = False
            self.l1111l1lll_opy_ = False
            self.l1l1ll1ll1l_opy_ = False
            self.l11l1llll1_opy_ = False
            self.l1ll1ll1111_opy_ = False
            self.l111ll1l11_opy_ = False
            self.l1lll11lll1_opy_ = False
            self.l111l1111l_opy_ = False
            self.l111111l1l_opy_ = False
            self.l1ll1l1ll1l_opy_ = False
            self.l1lll1lll11_opy_ = False
            self.l1l1ll11l11_opy_ = False
            self.l1ll111llll_opy_ = False
            self.l1ll111l1ll_opy_ = False
            self.l1ll11l1111_opy_ = False
            self.l1llll1l11l_opy_ = False
            self.l1ll1lll1l1_opy_ = False
            self.l1l1llllll1_opy_ = False
            self.l1llll111ll_opy_ = False
            self.l1ll11l1lll_opy_ = False
            self.l1l111lll1_opy_ = False
            self.l11ll1l1l_opy_ = False
            self.l1lll11l111_opy_ = False
            self.l111l11111_opy_ = False
            self.l1l11lllll_opy_ = False
            self.l11111l1ll_opy_ = False
            self.l1lllll1111_opy_ = False
            self.l1l11111l1_opy_ = False
            self.l11lll111_opy_ = False
            self.l1l1llll1ll_opy_ = False
            self.l1l1ll1l1ll_opy_ = False
            self.l111l1ll11_opy_ = False
            self.l11111l1l1_opy_ = False
            self.l11ll111ll_opy_ = False
            self.l11ll11lll_opy_ = False
            self.l111lllll1_opy_ = False
            self.l1ll11l1l11_opy_ = False
            self.l11l1lll1l_opy_ = False
            self.l1ll1l1l11_opy_ = False
            self.l11111l11l_opy_ = False
            self.l11111lll1_opy_ = False
            self.l1llll11l11_opy_ = False
            self.l11l1l11l1_opy_ = False
            self.l1ll1ll1lll_opy_ = False
            self.l11ll1l111_opy_ = False
            self.l1111lll1l_opy_ = False
            self.l1l1llll1l1_opy_ = False
            self.l1llll11lll_opy_ = False
            self.l1ll1l11ll1_opy_ = False
            self.l1lllllll1l_opy_ = False
            self.l1ll1l11lll_opy_ = ""
            self.l1ll1111ll1_opy_ = ""
            self._1l1l11ll_opy_ = l1l1l1l1ll_opy_
        def startDocument(self):
            self._1l1l11ll_opy_("Texts to find\nxml to model score\nOptimize model score2, chord assign\nOptimize model score2, with measure position\nmodel to braille\n\nStart reading xml file")
        def endDocument(self):
            self._1l1l11ll_opy_ ("End reading xml file\n")
            self._1l1l11ll_opy_ ("xml to model score, first extraction")
            self._1l1l11ll_opy_ (str(self.l1ll1111l_opy_))
        def startElement(self, name, attrs):
            if name == self.l1lll1l11l1_opy_:
                self.l1ll111ll1_opy_ = l1l1ll1ll11_opy_()
                self._1llll1l111_opy_ = 1
                keys = attrs.keys()
                if 'number' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('number')
                    self.l1ll111ll1_opy_.l1ll11111ll_opy_ (self.l1ll1111ll1_opy_)
                self.l1ll11l11l1_opy_ = True
            elif name == self.l1llll1l1l1_opy_:
                self.note = l11111l111_opy_()
                if self._1llll1l111_opy_ != 1:
                    self.note.l1l1llll11l_opy_ (self._1llll1l111_opy_)
                self.l1llllll1ll_opy_ = True
            elif name == self.l1lllll1lll_opy_:
                self.l1lll1ll1l1_opy_ = True
            elif name == self.l1ll1111l1l_opy_:
                self.note.rest = True
            elif name == self.l11l1l1l1l_opy_:
                self.note.l11111111_opy_ = True
            elif name == self.l1ll11ll111_opy_:
                keys = attrs.keys()
                if 'slash' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('slash')
                    self.note.l1l11l1l11_opy_ = self.l1ll1111ll1_opy_
                self.note.l1111111l_opy_ = True
            elif name == self.l1l1ll111l1_opy_:
                self.note.dot = True
            elif name == self.l111l1l1l1_opy_:
                self.l1ll1l111ll_opy_ = True
            elif name == self.l1l1ll1l111_opy_:
                self.l11l1l1l11_opy_ = True
            elif name == self.l11111llll_opy_:
                self.l1l1ll1llll_opy_ = True
            elif name == self.l1lll1llll1_opy_:
                self.l1111l1ll1_opy_ = True
            elif name == self.l1ll1l11l1l_opy_:
                self.l11l1lllll_opy_ = True
            elif name == self.l1l1ll11lll_opy_:
                self.l1ll1lllll1_opy_ = True
            elif name == self.l1llllll111_opy_:
                self.l1111l1lll_opy_ = True
            elif name == self.l11l11111l_opy_:
                self.note.l1l11l1ll1_opy_ = True
                keys = attrs.keys()
                if 'placement' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('placement')
                    self.note.l11l1l111_opy_ = self.l1ll1111ll1_opy_
                if 'number' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('number')
                    self.note.l1lll1l1l1l_opy_ (self.l1ll1111ll1_opy_)
                if 'type' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('type')
                    self.note.l1ll1l1l1l_opy_ = self.l1ll1111ll1_opy_
                self.l1l1ll1ll1l_opy_ = True
            elif name == self.l11111111l_opy_:
                self.l1l1ll11ll1_opy_ = l1lll11l11l_opy_()
                self.l11l1llll1_opy_ = True
            elif name == self.l1ll1lll111_opy_:
                self.l1ll1ll1111_opy_ = True
            elif name == self.l11ll111l1_opy_:
                self.l111ll1l11_opy_ = True
            elif name == self.l1lllll11ll_opy_:
                self.l1111l11ll_opy_ = l1llllll11l_opy_()
                self.l1lll11lll1_opy_ = True
            elif name == self.l1l1lllllll_opy_:
                self.l1lll1l111l_opy_ = l1ll1ll1l11_opy_()
                self.l1lll1l111l_opy_.l1lll11ll11_opy_ (self._111l11ll1_opy_["music_xml"]["ascending_chords"])
                keys = attrs.keys()
                if 'id' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('id')
                    self.l1lll1l111l_opy_.l111llll11_opy_ (self.l1ll1111ll1_opy_)
                self.l111l1111l_opy_ = True
            elif name == self.l111lll111_opy_:
                self.l111111l1l_opy_ = True
            elif name == self.l1111llll1_opy_:
                self.l1ll1l1ll1l_opy_ = True
            elif name == self.l1llll1ll1l_opy_:
                keys = attrs.keys()
                if 'id' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('id')
                    self.l1lll1l111l_opy_.l11l1lll11_opy_ (self.l1ll1111ll1_opy_)
                self.l1lll1lll11_opy_ = True
            elif name == self.l1ll1l111l1_opy_:
                self.l1l1ll11l11_opy_ = True
            elif name == self.l1111ll11l_opy_:
                keys = attrs.keys()
                if 'id' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('id')
                    self.l1lll1l111l_opy_.l11l1l1lll_opy_ (self.l1ll1111ll1_opy_)
                if 'port' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('port')
                    self.l1lll1l111l_opy_.l111ll11ll_opy_ (self.l1ll1111ll1_opy_)
                self.l1ll111llll_opy_ = True
            elif name == self.l11l1ll1ll_opy_:
                keys = attrs.keys()
                if 'id' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('id')
                    self.l1lll1l111l_opy_.l1llll1lll1_opy_ (self.l1ll1111ll1_opy_)
                self.l1ll111llll_opy_ = True
            elif name == self.l1ll1ll11ll_opy_:
                self.l1ll11l1111_opy_ = True
            elif name == self.l1lll111111_opy_:
                self.l1llll1l11l_opy_ = True
            elif name == self.l11111ll11_opy_:
                self.l1ll1lll1l1_opy_ = True
            elif name == self.l1lll1ll11l_opy_:
                self.l1l1llllll1_opy_ = True
            elif name == self.l111l1l1ll_opy_:
                self.part = l1lll1l1ll1_opy_()
                keys = attrs.keys()
                if 'id' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('id')
                    self.part.l111llll11_opy_ (self.l1ll1111ll1_opy_)
                self.l1llll111ll_opy_ = True
            elif name == self.l111ll1lll_opy_:
                self.l1ll11l111_opy_ = l1ll1l1ll11_opy_()
                if self._1llll1l111_opy_ != 1:
                    self.l1ll11l111_opy_.l1l1llll11l_opy_ (self._1llll1l111_opy_)
                self.l1ll11l1lll_opy_ 	= True
            elif name == self.l1ll1111l11_opy_:
                self.l1lllll11l_opy_ = l11111ll1l_opy_()
                self.l1l111lll1_opy_ = True
            elif name == self.l111l111l1_opy_:
                self.l1lll11l111_opy_ = True
            elif name == self.l11l11lll1_opy_:
                self.l111l11111_opy_ = True
            elif name == self.l111l1l11l_opy_:
                self.time = l1lllllllll_opy_()
                keys = attrs.keys()
                if 'symbol' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('symbol')
                    self.time.l1ll11lll11_opy_ (self.l1ll1111ll1_opy_)
                self.l1l11lllll_opy_ = True
            elif name == self.l1111l1l11_opy_:
                self.l11111l1ll_opy_ = True
            elif name == self.l11ll11l11_opy_:
                self.l1lllll1111_opy_ = True
            elif name == self.l111lll11l_opy_:
                self.l1111ll11_opy_ = l1ll1l1llll_opy_()
                self.l1l11111l1_opy_ = True
            elif name == self.l1ll111ll1l_opy_:
                self.l11l1ll111_opy_ = l1lllllll11_opy_()
                keys = attrs.keys()
                if 'number' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('number')
                    self.l11l1ll111_opy_.l11l11llll_opy_ (self.l1ll1111ll1_opy_)
                self.l11lll111_opy_ = True
            elif name == self.l1ll11l111l_opy_:
                self.l1l1llll1ll_opy_ = True
            elif name == self.l1lll11l1ll_opy_:
                self.l1l1ll1l1ll_opy_ = True
            elif name == self.l111l1l111_opy_:
                self.l111l1ll11_opy_ = True
            elif name == self.l1ll1l1111l_opy_:
                self.l1lll111lll_opy_ = l11l11ll1l_opy_()
                keys = attrs.keys()
                if 'parentheses' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('parentheses')
                    self.l1lll111lll_opy_.l1llll11111_opy_ (self.l1ll1111ll1_opy_)
                self.l11111l1l1_opy_ =                         True
            elif name == self.l1ll1l1l1ll_opy_:
                self.l11ll111ll_opy_ = True
            elif name == self.l1ll1l1lll1_opy_:
                self.l1lll111lll_opy_.l111ll1l1l_opy_ (True)
            elif name == self.l11l1l111l_opy_:
                self.l11ll11lll_opy_ = True
            elif name == self.l111ll111l_opy_:
                self.l111lllll1_opy_ = True
            elif name == self.l11l1111l1_opy_:
                self.l1l1lll1ll1_opy_ = l1ll111ll11_opy_()
                self._1llll1l111_opy_ = 2
                self.l1l1lll1ll1_opy_.l1l1llll11l_opy_ (2)
                if self._1llll1l111_opy_ != 1:
                    self.l1l1lll1ll1_opy_.l1l1llll11l_opy_ (self._1llll1l111_opy_)
                self.l1ll11l1l11_opy_ = True
            elif name == self.l1ll1111lll_opy_:
                self.key = l111lll1l1_opy_()
                self.l11ll1l1l_opy_ = True
            elif name == self.l1llll1llll_opy_:
                self.direction = l1lll111l11_opy_()
                if self._1llll1l111_opy_ != 1:
                    self.direction.l1l1llll11l_opy_ (self._1llll1l111_opy_)
                keys = attrs.keys()
                if 'placement' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('placement')
                    self.direction.l111111lll_opy_ (self.l1ll1111ll1_opy_)
                self.l1ll1l1l11_opy_ = True
            elif name in [self.l11l1111ll_opy_, self.l1ll11lll1l_opy_, self.l111l11l11_opy_, self.l1111lll11_opy_, self.l111l11lll_opy_, self.l1ll111l11l_opy_, self.l111l1lll1_opy_, self.l11l1l1ll1_opy_, self.l111111111_opy_, self.l1lll11ll1l_opy_, self.l1ll11ll11l_opy_, self.l1llll1ll11_opy_, self.l1lll1l1111_opy_, self.l111l1ll1l_opy_, self.l1111lllll_opy_, self.l1111ll1l1_opy_, self.l1lllll1l11_opy_, self.l1l1ll1lll1_opy_, self.l1ll11l1ll1_opy_, self.l1l1lll1l11_opy_, self.l11l11l111_opy_, self.l1ll1ll111l_opy_, self.l11l111111_opy_, self.N, self.l1l1ll1l1l1_opy_, self.l1lll1l11ll_opy_, self.l111llll1l_opy_]:
                self.l1l1l111l1_opy_ = l1lll1ll111_opy_()
                self.l1l1l111l1_opy_.l11l1l1111_opy_ (name)
                self.direction.l1ll1l11111_opy_ (self.l1l1l111l1_opy_)
            elif name == self.l1ll111lll1_opy_:
                self.words = l1lll11llll_opy_()
                self.direction.l1ll1l11111_opy_ (self.words)
                self.l11l1lll1l_opy_ = True
            elif name == self.l1ll1l1l11l_opy_:
                self.l11111l11l_opy_ = True
            elif name == self.l1l1lll1lll_opy_:
                self.l11111lll1_opy_ = True
            elif name == self.l1lllll1ll1_opy_:
                self.print = l1ll11ll1l1_opy_()
                keys = attrs.keys()
                if 'new-system' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('new-system')
                    self.print.l1lll111l1l_opy_ (self.l1ll1111ll1_opy_)
                self.l1ll111ll1_opy_.l1ll1l11111_opy_ (self.print)
                self.l1llll11l11_opy_ = True
            elif name == self.l1ll11lllll_opy_:
                self.print = l1ll11ll1l1_opy_()
                keys = attrs.keys()
                if 'number' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('number')
                    self.print.l11ll1l1l1_opy_ (self.l1ll1111ll1_opy_)
                if self.l1ll11l11l1_opy_ == True:
                    self.l1ll111ll1_opy_.l1ll1l11111_opy_ (self.print)
                self.l1llll11l11_opy_ = True
            elif name == self.l1ll111111l_opy_:
                self.l1ll1ll1lll_opy_ = True
            elif name == self.l1111111ll_opy_:
                self.l11ll1l111_opy_ = True
            elif name == self.l1ll111l1l1_opy_:
                self.l1111lll1l_opy_ = True
            elif name == self.l1ll1ll11l1_opy_:
                keys = attrs.keys()
                if 'type' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('type')
                self.note.l11l111l11_opy_ (True)
                self.note.l11l11ll11_opy_ (self.l1ll1111ll1_opy_)
            elif name == self.l1111ll111_opy_:
                self.l1ll1lll11l_opy_ = l11l11l1ll_opy_()
                if self._1llll1l111_opy_ != 1:
                    self.l1ll1lll11l_opy_.l1l1llll11l_opy_ (self._1llll1l111_opy_)
                keys = attrs.keys()
                if 'location' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('location')
                self.l1ll1lll11l_opy_.l11ll1111l_opy_ (self.l1ll1111ll1_opy_)
                self.l1l1llll1l1_opy_ = True
            elif name == self.l111l11l1l_opy_:
                self.l1llll11lll_opy_ = True
            elif name == self.REPEAT:
                keys = attrs.keys()
                if 'direction' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('direction')
                self.l1ll1lll11l_opy_.l1ll1llll1l_opy_ (self.l1ll1111ll1_opy_)
                self.l1ll1l11ll1_opy_ = True
            elif name == self.l11l1ll11l_opy_:
                self.l1ll1lll11l_opy_.l11l1ll1l1_opy_ (True)
                keys = attrs.keys()
                if 'number' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('number')
                    self.l1ll1lll11l_opy_.l1lll1lll1l_opy_ (self.l1ll1111ll1_opy_)
                keys = attrs.keys()
                if 'type' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('type')
                    self.l1ll1lll11l_opy_.l1ll1111111_opy_ (self.l1ll1111ll1_opy_)
                self.l1lllllll1l_opy_ = True
            elif name == self.l111l111ll_opy_:
                self.note.l1lll11l1l1_opy_ (True)
            elif name == self.l1l1lll11ll_opy_:
                self.note.l111lll1ll_opy_ (True)
            elif name == self.l1ll1llll11_opy_:
                self.note.l1l1llll111_opy_ (True)
            elif name == self.l1llll1111l_opy_:
                self.note.l1llllll1l1_opy_ (True)
            elif name == self.l1111l111l_opy_:
                self.note.l11ll11l1l_opy_ (True)
            elif name == self.l1ll111l111_opy_:
                self.note.l11l11l11l_opy_ (True)
            elif name == self.l1llll11ll1_opy_:
                self.l1lll1l1lll_opy_ = l11l11l1l1_opy_()
                self.l1lll1l1lll_opy_.l1ll11llll1_opy_ (True)
                keys = attrs.keys()
                if 'type' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('type')
                    self.l1lll1l1lll_opy_.l1llll111l1_opy_ (self.l1ll1111ll1_opy_)
                self.direction.l1ll1l11111_opy_ (self.l1lll1l1lll_opy_)
            elif name == self.l111l1llll_opy_:
                self.l1lllll1l1l_opy_ = l1ll11111l1_opy_()
                self.l1lllll1l1l_opy_.l1llll1l1ll_opy_ (True)
                keys = attrs.keys()
                if 'type' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('type')
                    self.l1lllll1l1l_opy_.l1lll111ll1_opy_ (self.l1ll1111ll1_opy_)
                self.direction.l1ll1l11111_opy_ (self.l1lllll1l1l_opy_)
            elif name == self.l1ll11ll1ll_opy_:
                self.l11l111ll1_opy_ = l111ll1ll1_opy_()
                self.l11l111ll1_opy_.l11ll1l11l_opy_ (True)
                keys = attrs.keys()
                if 'tempo' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('tempo')
                    self.l11l111ll1_opy_.l11ll11111_opy_ (self.l1ll1111ll1_opy_)
                if 'dynamics' in keys:
                    self.l1ll1111ll1_opy_ = attrs.getValue('dynamics')
                    self.l11l111ll1_opy_.l111ll1111_opy_ (self.l1ll1111ll1_opy_)
                if self.l1ll1l1l11_opy_:
                    self.direction.l1ll1l11111_opy_ (self.l11l111ll1_opy_)
        def endElement(self, name):
            if name == self.l1lll1l11l1_opy_:
                self.part.l1111111l1_opy_(self.l1ll111ll1_opy_)
                self.l1ll11l11l1_opy_ = False
            elif name == self.l1llll1l1l1_opy_:
                self.note.l1l1ll1l11l_opy_ ()
                self.l1ll111ll1_opy_.l1ll1l11111_opy_(self.note)
                self.l1llllll1ll_opy_ = False
            elif name == self.l1lllll1lll_opy_:
                self.note.l1l1ll11l1l_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l1lll1ll1l1_opy_ = False
            elif name == self.l111l1l1l1_opy_:
                self.note.l111111ll1_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l1ll1l111ll_opy_ = False
            elif name == self.l1l1ll1l111_opy_:
                self.note.l111l1ll1_opy_ = self.l1ll1l11lll_opy_
                self.l1ll1l11lll_opy_ = ""
                self.l11l1l1l11_opy_ = False
            elif name == self.l11111llll_opy_:
                self.note.l1lll1111ll_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l1l1ll1llll_opy_ = False
            elif name == self.l1lll1llll1_opy_:
                if self.l1ll11l1l11_opy_:
                    self.l1l1lll1ll1_opy_.l1lll1111l1_opy_ (self.l1ll1l11lll_opy_)
                else:
                    self.note.l1lll1111l1_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l1111l1ll1_opy_ = False
            elif name == self.l1ll1l11l1l_opy_:
                self.note.l1ll1l1l111_opy_ (self.l1ll1l11lll_opy_)
                self._1llll1l111_opy_ = self.l1ll1l11lll_opy_
                self.l1ll1l11lll_opy_ = ""
                self.l11l1lllll_opy_ = False
            elif name == self.l1l1ll11lll_opy_:
                self.note.l1llllllll1_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l1ll1lllll1_opy_ = False
            elif name == self.l1llllll111_opy_:
                if self.l1llllll1ll_opy_ == True:
                    self.note.l1llll11l1l_opy_ (self.l1ll1l11lll_opy_)
                if self.l1ll1l1l11_opy_ == True:
                    self.direction.l1llll11l1l_opy_ (self.l1ll1l11lll_opy_)
                if self.l11l1lll1l_opy_:
                    self.words.l1llll11l1l_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l1111l1lll_opy_ = False
            elif name == self.l11l11111l_opy_:
                self.l1l1ll1ll1l_opy_ = False
            elif name == self.l11111111l_opy_:
                self.l1ll1111l_opy_.l1ll1l11111_opy_ (self.l1l1ll11ll1_opy_)
                self.l11l1llll1_opy_ = False
            elif name == self.l1ll1lll111_opy_:
                self.l1l1ll11ll1_opy_.l1l1lll1l1l_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l1ll1ll1111_opy_ = False
            elif name == self.l11ll111l1_opy_:
                self.l1l1ll11ll1_opy_.l1l1lll11l1_opy_ (self.l1ll1l11lll_opy_.replace(" ", " "))
                self.l1ll1l11lll_opy_ = ""
                self.l111ll1l11_opy_ = False
            elif name == self.l1lllll11ll_opy_:
                self.l1ll1111l_opy_.l1ll1l11111_opy_ (self.l1111l11ll_opy_)
                self.l1lll11lll1_opy_ = False
            elif name == self.l1l1lllllll_opy_:
                self.l1111l11ll_opy_.l111ll11l1_opy_ (self.l1lll1l111l_opy_)
                self.l111l1111l_opy_ = False
            elif name == self.l111lll111_opy_:
                self.l1lll1l111l_opy_.l1111ll1ll_opy_ (self.l1ll1l11lll_opy_)
                if self.l1ll1l11lll_opy_ in ["Br Piano right hand", "Br Piano solo", "Brd Piano left hand"]:
                    self.l1lll1l111l_opy_.l1lll11ll11_opy_ (False)
                elif self.l1ll1l11lll_opy_ in ["Br Piano left hand", "Br Organ pedal", "Bru Piano right hand"]:
                    self.l1lll1l111l_opy_.l1lll11ll11_opy_ (True)
                self.l1ll1l11lll_opy_ = ""
                self.l111111l1l_opy_ = False
            elif name == self.l1111llll1_opy_:
                self.l1lll1l111l_opy_.l1ll1lll1ll_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l1ll1l1ll1l_opy_ = False
            elif name == self.l1llll1ll1l_opy_:
                self.l1lll1lll11_opy_ = False
            elif name == self.l1ll1l111l1_opy_:
                self.l1lll1l111l_opy_.l1lll1ll1ll_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l1l1ll11l11_opy_ = False
            elif name == self.l1111ll11l_opy_:
                self.l1ll111llll_opy_ = False
            elif name == self.l11l1ll1ll_opy_:
                self.l1ll111l1ll_opy_ = False
            elif name == self.l1ll1ll11ll_opy_:
                self.l1lll1l111l_opy_.l1l1lllll1l_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l1ll11l1111_opy_ = False
            elif name == self.l1lll111111_opy_:
                self.l1lll1l111l_opy_.l1111l1l1l_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l1llll1l11l_opy_ = False
            elif name == self.l11111ll11_opy_:
                self.l1lll1l111l_opy_.l11ll11ll1_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l1ll1lll1l1_opy_ = False
            elif name == self.l1lll1ll11l_opy_:
                self.l1lll1l111l_opy_.l1lllll11l1_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l1l1llllll1_opy_ = False
            elif name == self.l111l1l1ll_opy_:
                self.l1ll1111l_opy_.l1ll1l11111_opy_ (self.part)
                self.l1llll111ll_opy_ = False
            elif name == self.l111ll1lll_opy_:
                self.l1ll111ll1_opy_.l1ll1l11111_opy_ (self.l1ll11l111_opy_)
                self.l1ll11l1lll_opy_ = False
            elif name == self.l1ll1111l11_opy_:
                self.l1lllll11l_opy_.l1l1lll1111_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll11l111_opy_.l1ll1l11111_opy_(self.l1lllll11l_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l1l111lll1_opy_ = False
            elif name == self.l111l111l1_opy_:
                self.key.l111llllll_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l1lll11l111_opy_ = False
            elif name == self.l11l11lll1_opy_:
                self.key.l111111l11_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l111l11111_opy_ = False
            elif name == self.l111l1l11l_opy_:
                self.l1ll11l111_opy_.l1ll1l11111_opy_(self.time)
                self.l1l11lllll_opy_ = False
            elif name == self.l1111l1l11_opy_:
                self.time.l11l111lll_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l11111l1ll_opy_ = False
            elif name == self.l11ll11l11_opy_:
                self.time.l1lll1lllll_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l1lllll1111_opy_ = False
            elif name == self.l111lll11l_opy_:
                self.l1111ll11_opy_.l1ll11l1l1l_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll11l111_opy_.l1ll1l11111_opy_(self.l1111ll11_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l1l11111l1_opy_ = False
            elif name == self.l1ll111ll1l_opy_:
                self.l1ll11l111_opy_.l1ll1l11111_opy_ (self.l11l1ll111_opy_)
                self.l11lll111_opy_ = False
            elif name == self.l1ll11l111l_opy_:
                self.l11l1ll111_opy_.l1111l1111_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l1l1llll1ll_opy_ = False
            elif name == self.l1lll11l1ll_opy_:
                self.l11l1ll111_opy_.l1l1lllll11_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l1l1ll1l1ll_opy_ = False
            elif name == self.l111l1l111_opy_:
                self.l11l1ll111_opy_.l1ll1ll1l1l_opy_(self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l111l1ll11_opy_ = False
            elif name == self.l1ll1l1111l_opy_:
                self.direction.l1ll1l11111_opy_ (self.l1lll111lll_opy_)
                self.l11111l1l1_opy_ = False
            elif name == self.l1ll1l1l1ll_opy_:
                self.l1lll111lll_opy_.l1111l11l1_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l11ll111ll_opy_ = False
            elif name == self.l11l1l111l_opy_:
                self.l1lll111lll_opy_.l1lll1l1l11_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l11ll11lll_opy_ = False
            elif name == self.l111ll111l_opy_:
                self.note.l1llllll1l_opy_ = self.l1ll1l11lll_opy_
                self.l1ll1l11lll_opy_ = ""
                self.l111lllll1_opy_ = False
            elif name == self.l11l1111l1_opy_:
                self.l1ll111ll1_opy_.l1ll1l11111_opy_(self.l1l1lll1ll1_opy_)
                self.l1ll11l1l11_opy_ = False
            elif name == self.l1ll1111lll_opy_:
                self.l1ll11l111_opy_.l1ll1l11111_opy_(self.key)
                self.l11ll1l1l_opy_ = False
            elif name == self.l1ll111lll1_opy_:
                self.words.l1ll1l11l11_opy_ (self.l1ll1l11lll_opy_.replace(" "," "))
                self.l1ll1l11lll_opy_ = ""
                self.l11l1lll1l_opy_ = False
            elif name == self.l1llll1llll_opy_:
                self.l1ll111ll1_opy_.l1ll1l11111_opy_ (self.direction)
                self.l1ll1l1l11_opy_ = False
            elif name == self.l1ll1l1l11l_opy_:
                self.note.l1ll11l11ll_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l11111l11l_opy_ = False
            elif name == self.l1l1lll1lll_opy_:
                self.note.l1l1ll111ll_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l11111lll1_opy_ = False
            elif name == self.l1lllll1ll1_opy_:
                self.l1llll11l11_opy_ = False
            elif name == self.l1ll11lllll_opy_:
                self.l11l1l11l1_opy_ = False
            elif name == self.l1ll111111l_opy_:
                self.l1ll1ll1lll_opy_ = False
            elif name == self.l1111111ll_opy_:
                self.note.l11l1l11ll_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l11ll1l111_opy_ = False
            elif name == self.l1ll111l1l1_opy_:
                self.note.l1lllll111l_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l1111lll1l_opy_ = False
            elif name == self.l1111ll111_opy_:
                self.l1ll111ll1_opy_.l1ll1l11111_opy_ (self.l1ll1lll11l_opy_)
                self.l1l1llll1l1_opy_ = False
            elif name == self.l111l11l1l_opy_:
                self.l1ll1lll11l_opy_.l11l111l1l_opy_ (self.l1ll1l11lll_opy_)
                self.l1ll1l11lll_opy_ = ""
                self.l1llll11lll_opy_ = False
            elif name == self.REPEAT:
                self.l1ll1l11ll1_opy_ = False
            elif name == self.l11l1ll11l_opy_:
                self.l1lllllll1l_opy_ = False
        def characters(self, content):
            if self.l1lll1ll1l1_opy_ or self.l1ll1l111ll_opy_ or self.l11l1l1l11_opy_ or self.l1l1ll1llll_opy_ or self.l1111l1ll1_opy_ or self.l11l1lllll_opy_ or self.l1ll1lllll1_opy_ or self.l1111l1lll_opy_ or self.l1ll1ll1111_opy_ or self.l111ll1l11_opy_ or self.l1l111lll1_opy_ or self.l1lll11l111_opy_ or self.l111l11111_opy_ or self.l11111l1ll_opy_ or self.l1lllll1111_opy_ or self.l1l11111l1_opy_ or self.l1l1llll1ll_opy_ or self.l1l1ll1l1ll_opy_ or self.l11ll111ll_opy_ or self.l11ll11lll_opy_ or self.l111lllll1_opy_ or self.l111111l1l_opy_ or self.l1ll1l1ll1l_opy_ or self.l1l1ll11l11_opy_ or self.l1ll11l1111_opy_ or self.l1llll1l11l_opy_ or self.l1ll1lll1l1_opy_ or self.l1l1llllll1_opy_ or self.l11l1lll1l_opy_ or self.l11111l11l_opy_ or self.l11111lll1_opy_ or self.l11ll1l111_opy_ or self.l1111lll1l_opy_ or self.l1llll11lll_opy_ or self.l111l1ll11_opy_:
                self.l1ll1l11lll_opy_ += content
    def l1l1lll111l_opy_(self, l1l1l1l1ll_opy_, l1ll1111l_opy_):
        parser = xml.sax.make_parser()
        xml.sax.InputSource.setEncoding(parser, encoding="utf-8")
        parser.setFeature(xml.sax.handler.feature_namespaces, 0)
        handler = self.l1lll11111l_opy_(l1l1l1l1ll_opy_, l1ll1111l_opy_, self.l1l1l11l1_opy_)
        parser.setContentHandler(handler)
        if os.stat(self._1ll11111_opy_).st_size > 2:
            parser.parse(self._1ll11111_opy_)