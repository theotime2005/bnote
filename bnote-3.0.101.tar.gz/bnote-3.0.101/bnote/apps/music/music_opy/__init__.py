"""
Copyright (c)2021 eurobraille
This software is the proprietary of eurobraille and may not be copied,
distributed, published,or disclosed without express prior written permission.
"""

from .music_read_file import MusicReadFile
from .music_write_file import MusicWriteFile
