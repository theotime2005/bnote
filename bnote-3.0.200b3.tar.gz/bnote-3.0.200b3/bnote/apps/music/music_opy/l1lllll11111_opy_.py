"""
Copyright (c)2021 eurobraille
This software is the proprietary of eurobraille and may not be copied,
distributed, published,or disclosed without express prior written permission.
"""


class l1ll1ll11l1_opy_:
    # for l1llll1ll1ll_opy_ to braille l1llll1ll1l1_opy_
    l1llll1lll11_opy_ = 5  # 0 no, 1 xml, 2 l1llll1lll1l_opy_, 3 l1llll1llll1_opy_, 4 xml + l1llll1lll1l_opy_, 5 xml + l1llll1llll1_opy_, 6 l1llll1lll1l_opy_ + l1llll1llll1_opy_, 7 xml + l1llll1lll1l_opy_ + l1llll1llll1_opy_
    l1llll1lllll_opy_ = 6  # 0 no, 1 xml, 2 l1llll1lll1l_opy_, 3 l1llll1llll1_opy_, 4 xml + l1llll1lll1l_opy_, 5 xml + l1llll1llll1_opy_, 6 l1llll1lll1l_opy_ + l1llll1llll1_opy_, 7 xml + l1llll1lll1l_opy_ + l1llll1llll1_opy_
