"""
Copyright (c)2021 eurobraille
This software is the proprietary of eurobraille and may not be copied,
distributed, published,or disclosed without express prior written permission.
"""
from .l1l111ll1_opy_ import *

l11ll1l111_opy_ = {l1l111l111l_opy_.l11111111ll_opy_.a: "A", l1l111l111l_opy_.l11111111ll_opy_.b: "B",
                   l1l111l111l_opy_.l11111111ll_opy_.c: "C", l1l111l111l_opy_.l11111111ll_opy_.d: "D",
                   l1l111l111l_opy_.l11111111ll_opy_.e: "E", l1l111l111l_opy_.l11111111ll_opy_.f: "F",
                   l1l111l111l_opy_.l11111111ll_opy_.g: "G"}
l11l1lll11_opy_ = {l1l111l111l_opy_.l1llllllll11_opy_.l1111111l11_opy_: "-2",
                   l1l111l111l_opy_.l1llllllll11_opy_.l1lllllll1ll_opy_: "-1.5",
                   l1l111l111l_opy_.l1llllllll11_opy_.l111111111l_opy_: "-1",
                   l1l111l111l_opy_.l1llllllll11_opy_.l1lllllll1l1_opy_: "-0.5",
                   l1l111l111l_opy_.l1llllllll11_opy_.l1llllllllll_opy_: "no",
                   l1l111l111l_opy_.l1llllllll11_opy_.l11111111l1_opy_: "0.5",
                   l1l111l111l_opy_.l1llllllll11_opy_.l1lllllllll1_opy_: "1",
                   l1l111l111l_opy_.l1llllllll11_opy_.l1111111111_opy_: "1.5",
                   l1l111l111l_opy_.l1llllllll11_opy_.l1llllllll1l_opy_: "2"}
l111ll1l11_opy_ = {l1l111l111l_opy_.l1lllll1ll11_opy_.l1lllllll111_opy_: "maxima",
                   l1l111l111l_opy_.l1lllll1ll11_opy_.l1llllll1ll1_opy_: "long",
                   l1l111l111l_opy_.l1lllll1ll11_opy_.l1llllll1l1l_opy_: "breve",
                   l1l111l111l_opy_.l1lllll1ll11_opy_.l1lllll1ll1l_opy_: "whole",
                   l1l111l111l_opy_.l1lllll1ll11_opy_.l1llllll11l1_opy_: "half",
                   l1l111l111l_opy_.l1lllll1ll11_opy_.l1lllll1l1ll_opy_: "quarter",
                   l1l111l111l_opy_.l1lllll1ll11_opy_.l1llllll11ll_opy_: "eighth",
                   l1l111l111l_opy_.l1lllll1ll11_opy_.l1llllll111l_opy_: "16th",
                   l1l111l111l_opy_.l1lllll1ll11_opy_.l1lllll1llll_opy_: "32nd",
                   l1l111l111l_opy_.l1lllll1ll11_opy_.l1llllll1111_opy_: "64th",
                   l1l111l111l_opy_.l1lllll1ll11_opy_.l1llllll1l11_opy_: "128th",
                   l1l111l111l_opy_.l1lllll1ll11_opy_.l1lllllll11l_opy_: "256th",
                   l1l111l111l_opy_.l1lllll1ll11_opy_.l1lllll1lll1_opy_: "512th",
                   l1l111l111l_opy_.l1lllll1ll11_opy_.l1llllll1lll_opy_: "1024th"}
