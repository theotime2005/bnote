"""
Copyright (c)2021 eurobraille
This software is the proprietary of eurobraille and may not be copied,
distributed, published,or disclosed without express prior written permission.
"""
from enum import Enum
class l1lll1l1l11l_opy_:
    def __init__(self):
        pass
    def __str__(self):
        return self.l1llll111lll_opy_(0)
    def l1llll111lll_opy_(self, level):
        pass
class l1l111l111l_opy_(l1lll1l1l11l_opy_):
    class l11111111ll_opy_(Enum):
        a = object()
        b = object()
        c = object()
        d = object()
        e = object()
        f = object()
        g = object()
    class l1llllllll11_opy_(Enum):
        l1llllllllll_opy_ = object()
        l1lllllllll1_opy_ = object()
        l1llllllll1l_opy_ = object()
        l111111111l_opy_ = object()
        l1111111l11_opy_ = object()
        l11111111l1_opy_ = object()
        l1lllllll1l1_opy_ = object()
        l1111111111_opy_ = object()
        l1lllllll1ll_opy_ = object()
    class l1lllll1ll11_opy_(Enum):
        l1lllllll111_opy_ = object()
        l1llllll1ll1_opy_ = object()
        l1llllll1l1l_opy_ = object()
        l1lllll1ll1l_opy_ = object()
        l1llllll11l1_opy_ = object()
        l1lllll1l1ll_opy_ = object()
        l1llllll11ll_opy_ = object()
        l1llllll111l_opy_ = object()
        l1lllll1llll_opy_ = object()
        l1llllll1111_opy_ = object()
        l1llllll1l11_opy_ = object()
        l1lllllll11l_opy_ = object()
        l1lllll1lll1_opy_ = object()
        l1llllll1lll_opy_ = object()
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "note"
        self.rest = False
        self.l1lll1l11l1_opy_ = False
        self.l1111lll1l_opy_ = False
        self.l11lll1111_opy_ = "missing"
        self.l1ll1llll11_opy_ = 0
        self.step = "no"
        self.l11lll11ll_opy_ = "no"
        self.l1llll11ll1_opy_ = "no"
        self.l1l11111ll_opy_ = 100
        self.l11lll1l11_opy_ = 0
        self.l1111l1lll_opy_ = 0
        self.type = "no"
        self.dot = False
        self.l11111ll11_opy_ = 1
        self.l11llll111_opy_ = "no"
        self.l1llllll1ll_opy_ = False
        self.l11l1111ll_opy_ = "no"
        self.l1lll1111ll_opy_ = "no"
        self.l1111l1l11_opy_ = "no"
        self.l111ll11l1_opy_ = False
        self.l1llll1lll1_opy_ = "no"
        self.l11l11l1ll_opy_ = "no"
        self.l11l111l11_opy_ = "no"
        self.l1l11l11l1_opy_ = False
        self.l1l1111111_opy_ = "no"
        self.l1lll1l111l1_opy_ = False
        self.l1lll1llll11_opy_ = "no"
        self.l1llllll11l_opy_ = 0
        self.l1lll1lll11_opy_ = 0
        self.l1llll111ll1_opy_ = 0
        self.l1llll11ll1l_opy_ = 0
        self.l1llll11l1ll_opy_ = 0
        self.l1lll1lll111_opy_ = 0
        self.l1llll1l111l_opy_ = 0
        self.l111llllll_opy_ = "no"
        self.text = ""
        self.l1llll1l1l1_opy_ = False
        self.l1l111l11l_opy_ = False
        self.l1lll1l1lll_opy_ = False
        self.l1l11l1l1l_opy_ = False
        self.l1llll111l1_opy_ = False
        self.l11llllll1_opy_ = False
        self.l1l111l111_opy_ = False
        self.l11ll11l1l_opy_ = "no"
        self.l1lll1ll11l_opy_ = "no"
        self.l111l11l11_opy_ = False
        self.l1lll1ll1ll_opy_ = "no"
        self.l1l11ll1l1_opy_ = "no"
        self.l11l1ll111_opy_ = False
        self.l1lllll11l1_opy_ = "no"
        self.l1lllllll11_opy_ = False
        self.l111l1lll1_opy_ = "no"
        self.l1lll1l11ll1_opy_ = 0
        self.l1lll1llllll_opy_ = 1
    def l1lll1l1ll1l_opy_(self, rest):
        self.rest = rest
    def l1lll1lll11l_opy_(self, l1lll1l11l1_opy_):
        self.l1lll1l11l1_opy_ = l1lll1l11l1_opy_
    def l1l1111l1_opy_(self, l1ll1llll11_opy_):
        self.l1ll1llll11_opy_ = l1ll1llll11_opy_
    def l1llll1ll11l_opy_(self, l1111lll1l_opy_):
        self.l1111lll1l_opy_ = l1111lll1l_opy_
    def l1lll1lll1l1_opy_(self, l11lll1111_opy_):
        self.l11lll1111_opy_ = l11lll1111_opy_
    def l1l11l1ll11_opy_(self, step):
        l1lll1l1lll1_opy_ = {"A": l1l111l111l_opy_.l11111111ll_opy_.a, "B": l1l111l111l_opy_.l11111111ll_opy_.b, "C": l1l111l111l_opy_.l11111111ll_opy_.c, "D": l1l111l111l_opy_.l11111111ll_opy_.d, "E": l1l111l111l_opy_.l11111111ll_opy_.e,
                     "F": l1l111l111l_opy_.l11111111ll_opy_.f, "G": l1l111l111l_opy_.l11111111ll_opy_.g, "no": "no"}
        self.step = l1lll1l1lll1_opy_[step]
    def l1l1111lll1_opy_(self, l11lll11ll_opy_):
        l1llll1l1lll_opy_ = {"-2": l1l111l111l_opy_.l1llllllll11_opy_.l1111111l11_opy_, "-1.5": l1l111l111l_opy_.l1llllllll11_opy_.l1lllllll1ll_opy_, "-1": l1l111l111l_opy_.l1llllllll11_opy_.l111111111l_opy_, "-0.5": l1l111l111l_opy_.l1llllllll11_opy_.l1lllllll1l1_opy_, "0": l1l111l111l_opy_.l1llllllll11_opy_.l1llllllllll_opy_, "": l1l111l111l_opy_.l1llllllll11_opy_.l1llllllllll_opy_, "0.5": l1l111l111l_opy_.l1llllllll11_opy_.l11111111l1_opy_, "1": l1l111l111l_opy_.l1llllllll11_opy_.l1lllllllll1_opy_, "1.5": l1l111l111l_opy_.l1llllllll11_opy_.l1111111111_opy_, "2": l1l111l111l_opy_.l1llllllll11_opy_.l1llllllll1l_opy_, "no": "no"}
        self.l11lll11ll_opy_ = l1llll1l1lll_opy_[l11lll11ll_opy_]
    def l1llll1l1l11_opy_(self, l1llll11ll1_opy_):
        self.l1llll11ll1_opy_ = l1llll11ll1_opy_
    def l111lll11l1_opy_(self, l1l11111ll_opy_):
        self.l1l11111ll_opy_ = int(l1l11111ll_opy_)
    def l11lll1111l_opy_(self, l11lll1l11_opy_):
        self.l11lll1l11_opy_ = int(l11lll1l11_opy_)
    def l11ll11lll1_opy_(self, l1111l1lll_opy_):
        self.l1111l1lll_opy_ = int(l1111l1lll_opy_)
    def l11ll1l1l1l_opy_(self, l1llll111l11_opy_):
        l1lll1ll11ll_opy_ = {"maxima": l1l111l111l_opy_.l1lllll1ll11_opy_.l1lllllll111_opy_, "long": l1l111l111l_opy_.l1lllll1ll11_opy_.l1llllll1ll1_opy_, "breve": l1l111l111l_opy_.l1lllll1ll11_opy_.l1llllll1l1l_opy_,
                     "whole": l1l111l111l_opy_.l1lllll1ll11_opy_.l1lllll1ll1l_opy_, "half": l1l111l111l_opy_.l1lllll1ll11_opy_.l1llllll11l1_opy_, "quarter": l1l111l111l_opy_.l1lllll1ll11_opy_.l1lllll1l1ll_opy_,
                     "eighth": l1l111l111l_opy_.l1lllll1ll11_opy_.l1llllll11ll_opy_, "16th": l1l111l111l_opy_.l1lllll1ll11_opy_.l1llllll111l_opy_, "32nd": l1l111l111l_opy_.l1lllll1ll11_opy_.l1lllll1llll_opy_,
                     "64th": l1l111l111l_opy_.l1lllll1ll11_opy_.l1llllll1111_opy_, "128th": l1l111l111l_opy_.l1lllll1ll11_opy_.l1llllll1l11_opy_, "256th": l1l111l111l_opy_.l1lllll1ll11_opy_.l1lllllll11l_opy_,
                     "512th": l1l111l111l_opy_.l1lllll1ll11_opy_.l1lllll1lll1_opy_, "1024th": l1l111l111l_opy_.l1lllll1ll11_opy_.l1llllll1lll_opy_}
        self.type = l1lll1ll11ll_opy_[l1llll111l11_opy_]
    def l1lll1l1l111_opy_(self, dot):
        self.dot = dot
    def l1l1l1ll11l_opy_(self, l11111ll11_opy_):
        self.l11111ll11_opy_ = int(l11111ll11_opy_)
    def l1lll1ll1ll1_opy_(self, l11llll111_opy_):
        self.l11llll111_opy_ = l11llll111_opy_
    def l1llll1l1111_opy_(self, l1llllll1ll_opy_):
        self.l1llllll1ll_opy_ = l1llllll1ll_opy_
    def l1lll1ll1l1l_opy_(self, l11l1111ll_opy_):
        self.l11l1111ll_opy_ = l11l1111ll_opy_
    def l11l1l111l1_opy_(self, l1lll1111ll_opy_):
        self.l1lll1111ll_opy_ = l1lll1111ll_opy_
    def l1llll111111_opy_(self, l1111l1l11_opy_):
        self.l1111l1l11_opy_ = l1111l1l11_opy_
    def l1lll1ll11l1_opy_(self, l111ll11l1_opy_):
        self.l111ll11l1_opy_ = l111ll11l1_opy_
    def l1lll1l11l1l_opy_(self, l1llll1lll1_opy_):
        self.l1llll1lll1_opy_ = l1llll1lll1_opy_
    def l1lll1ll1l11_opy_(self, l11l11l1ll_opy_):
        self.l11l11l1ll_opy_ = l11l11l1ll_opy_
    def l1llll11llll_opy_(self, l11l111l11_opy_):
        self.l11l111l11_opy_ = l11l111l11_opy_
    def l1l11lll1l1_opy_(self, l1l11l11l1_opy_):
        self.l1l11l11l1_opy_ = l1l11l11l1_opy_
    def l11llllll1l_opy_(self, l1l1111111_opy_):
        if self.l1l1111111_opy_ == "stop" and l1l1111111_opy_ == "start":
            self.l1l1111111_opy_ = "stop-start"
        else:
            self.l1l1111111_opy_ = l1l1111111_opy_
    def l1llll1ll111_opy_(self, l1lll1l111l1_opy_):
        self.l1lll1l111l1_opy_ = l1lll1l111l1_opy_
    def l1lll1l11lll_opy_(self, l1lll1llll11_opy_):
        if self.l1lll1llll11_opy_ == "stop" and l1lll1llll11_opy_ == "start":
            self.l1lll1llll11_opy_ = "stop-start"
        else:
            self.l1lll1llll11_opy_ = l1lll1llll11_opy_
    def l1l1lllll11_opy_(self, l1llllll11l_opy_):
        self.l1llllll11l_opy_ = int(l1llllll11l_opy_)
    def l11ll1lll11_opy_(self, l1lll1lll11_opy_):
        self.l1lll1lll11_opy_ = int(l1lll1lll11_opy_)
    def l11lll111_opy_(self, l1llll111ll1_opy_):
        self.l1llll111ll1_opy_ = l1llll111ll1_opy_
    def l1lll1llll1l_opy_(self, l1llll11ll1l_opy_):
        self.l1llll11ll1l_opy_ = l1llll11ll1l_opy_
    def l1lll1ll1lll_opy_(self, l1llll11l1ll_opy_):
        self.l1llll11l1ll_opy_ = l1llll11l1ll_opy_
    def l1ll111llll_opy_(self):
        l1llll1l11ll_opy_ = {l1l111l111l_opy_.l11111111ll_opy_.c: 0, l1l111l111l_opy_.l11111111ll_opy_.d: 1, l1l111l111l_opy_.l11111111ll_opy_.e: 2, l1l111l111l_opy_.l11111111ll_opy_.f: 3,
                           l1l111l111l_opy_.l11111111ll_opy_.g: 4, l1l111l111l_opy_.l11111111ll_opy_.a: 5, l1l111l111l_opy_.l11111111ll_opy_.b: 6, "no": 0}
        self.l1llll1l111l_opy_ = self.l1l11111ll_opy_ * 7 + l1llll1l11ll_opy_ [self.step]
    def l1l111l11ll_opy_(self, l111llllll_opy_):
        self.l111llllll_opy_ = l111llllll_opy_
    def l1111l11lll_opy_(self, text):
        if self.text == "":
            self.text = text
        else:
            self.text += " " + text
    def l11lll1l1l1_opy_(self, l1llll1l1l1_opy_):
        self.l1llll1l1l1_opy_ = l1llll1l1l1_opy_
    def l11l1ll1l11_opy_(self, l1l111l11l_opy_):
        self.l1l111l11l_opy_ = l1l111l11l_opy_
    def l1l111l1l11_opy_(self, l1lll1l1lll_opy_):
        self.l1lll1l1lll_opy_ = l1lll1l1lll_opy_
    def l11l11111ll_opy_(self, l1l11l1l1l_opy_):
        self.l1l11l1l1l_opy_ = l1l11l1l1l_opy_
    def l11l1l1111l_opy_(self, l1llll111l1_opy_):
        self.l1llll111l1_opy_ = l1llll111l1_opy_
    def l11ll11l111_opy_(self, l11llllll1_opy_):
        self.l11llllll1_opy_ = l11llllll1_opy_
    def l111l11ll1l_opy_(self, l1l111l111_opy_):
        self.l1l111l111_opy_ = l1l111l111_opy_
    def l1l11111ll1_opy_(self, l11ll11l1l_opy_):
        self.l11ll11l1l_opy_ = l11ll11l1l_opy_
    def l111ll111ll_opy_(self, l1lll1ll11l_opy_):
        self.l1lll1ll11l_opy_ = l1lll1ll11l_opy_
    def l111l11111l_opy_(self, l111l11l11_opy_):
        self.l111l11l11_opy_ = l111l11l11_opy_
    def l111l1lll11_opy_(self, l1lll1ll1ll_opy_):
        self.l1lll1ll1ll_opy_ = l1lll1ll1ll_opy_
    def l1l1lll1ll1_opy_(self, l1l11ll1l1_opy_):
        self.l1l11ll1l1_opy_ = l1l11ll1l1_opy_
    def l11l1l11ll1_opy_(self, l11l1ll111_opy_):
        self.l11l1ll111_opy_ = l11l1ll111_opy_
    def l1l1l111111_opy_ (self, l1lllll11l1_opy_):
        self.l1lllll11l1_opy_ = l1lllll11l1_opy_
    def l1l11ll111l_opy_(self, l1lllllll11_opy_):
        self.l1lllllll11_opy_ = l1lllllll11_opy_
    def l1l1l1l11ll_opy_ (self, l111l1lll1_opy_):
        self.l111l1lll1_opy_ = l111l1lll1_opy_
    def l1ll111l1ll_opy_(self, l1lll1llllll_opy_):
        self.l1lll1llllll_opy_ = int(l1lll1llllll_opy_)
    def l1llll111lll_opy_(self, level):
        return " " * level +\
               "note : measure position<{}> end measure position<{} duration<{}> beat_number<{}> beat_position<{}> rest<{}> chord<{}> chord-state<{}> grace<{}> slash<{}> step<{}> alter<{}> accidental<{}> octave<{}> voice<{}> type<{}> dot<{}> staff<{}> finger<{}> slur<{}> slur_placement<{}> slur_number<{}> slur_type<{}> slur2<{}> slur_placement2<{}> slur_number2<{}> slur_type2<{}> tie<{}> tie-type<{}> tied<{}> tied-type<{}> actual-notes<{}> normal-notes<{}> note_hight<{}> syllabic<{}> text<{}> staccato<{}> staccatissimo<{}> accent<{}> breath-mark<{}> fermata<{}> trill<{}> inverted-mordent<{}> inverted-mordent-placement<{}> inverted-mordent-long<{}> mordent<{}> mordent-placement<{}> mordent-long<{}> arpeggiate<{}> arpeggiate-direction<{}> two-hands-arpeggiate<{}> two-hands-arpeggiate-direction<{}> current_voice<{}> braille-group<{}>\n".format(self.l1llll111ll1_opy_, self.l1llll11ll1l_opy_, self.l11lll1l11_opy_, self.l1llll11l1ll_opy_, self.l1lll1lll111_opy_, self.rest, self.l1lll1l11l1_opy_, self.l1ll1llll11_opy_, self.l1111lll1l_opy_, self.l11lll1111_opy_, self.step, self.l11lll11ll_opy_, self.l1llll11ll1_opy_, self.l1l11111ll_opy_, self.l1111l1lll_opy_, self.type, self.dot, self.l11111ll11_opy_, self.l11llll111_opy_, self.l1llllll1ll_opy_, self.l11l1111ll_opy_, self.l1lll1111ll_opy_, self.l1111l1l11_opy_, self.l111ll11l1_opy_, self.l1llll1lll1_opy_, self.l11l11l1ll_opy_, self.l11l111l11_opy_, self.l1l11l11l1_opy_, self.l1l1111111_opy_, self.l1lll1l111l1_opy_, self.l1lll1llll11_opy_, self.l1llllll11l_opy_, self.l1lll1lll11_opy_, self.l1llll1l111l_opy_, self.l111llllll_opy_, self.text, self.l1llll1l1l1_opy_, self.l1l111l11l_opy_, self.l1lll1l1lll_opy_, self.l1l11l1l1l_opy_, self.l1llll111l1_opy_, self.l11llllll1_opy_, self.l1l111l111_opy_, self.l11ll11l1l_opy_, self.l1lll1ll11l_opy_, self.l111l11l11_opy_, self.l1lll1ll1ll_opy_, self.l1l11ll1l1_opy_, self.l11l1ll111_opy_, self.l1lllll11l1_opy_, self.l1lllllll11_opy_, self.l111l1lll1_opy_, self.l1lll1llllll_opy_, self.l1lll1l11ll1_opy_)
class l111ll1ll1l_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "backup"
        self.l11lll1l11_opy_ = 0
        self.l1llll111ll1_opy_ = 0
        self.l1llll1l1ll1_opy_ = False
        self.l1llll1l11l1_opy_ = False
        self.l11111ll11_opy_ = 1
        self.l1lll1llllll_opy_ = 1
    def l11lll1111l_opy_(self, l11lll1l11_opy_):
        self.l11lll1l11_opy_ = int(l11lll1l11_opy_)
    def l11lll111_opy_(self, l1llll111ll1_opy_):
        self.l1llll111ll1_opy_ = l1llll111ll1_opy_
    def l1lll1lllll1_opy_(self, l1llll1l1ll1_opy_):
        self.l1llll1l1ll1_opy_ = l1llll1l1ll1_opy_
    def l1llll11l111_opy_(self, l1llll1l11l1_opy_):
        self.l1llll1l11l1_opy_ = l1llll1l11l1_opy_
    def l1l1l1ll11l_opy_(self, l11111ll11_opy_):
        self.l11111ll11_opy_ = l11111ll11_opy_
    def l1ll111l1ll_opy_(self, l1lll1llllll_opy_):
        self.l1lll1llllll_opy_ = int(l1lll1llllll_opy_)
    def l1llll111lll_opy_(self, level):
        return " " * level + "backup : measure position<{}> duration<{}> full measure<{}> same staff<{}> staff<{}> current_voice<{}>\n".format(self.l1llll111ll1_opy_, self.l11lll1l11_opy_, self.l1llll1l1ll1_opy_, self.l1llll1l11l1_opy_, self.l11111ll11_opy_, self.l1lll1llllll_opy_)
class l1l1l11l111_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "key"
        self.l1lll1l1l11_opy_ = 100
        self.mode = "no"
    def l11ll1ll111_opy_(self, l1lll1l1l11_opy_=100):
        self.l1lll1l1l11_opy_ = int(l1lll1l1l11_opy_)
    def l111l11l111_opy_(self, mode="no"):
        self.mode = mode
    def l1llll111lll_opy_(self, level):
        return " " * level + "key : fifths<{}> mode<{}>\n".format(self.l1lll1l1l11_opy_, self.mode)
class l1l1ll11111_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "time"
        self.l1l1l11111_opy_ = "4"
        self.l1111lll11_opy_ = "4"
        self.l11lllll1l_opy_ = "no"
    def l1111ll1l11_opy_(self, l1l1l11111_opy_="0"):
        self.l1l1l11111_opy_ = l1l1l11111_opy_
    def l1l1ll111l1_opy_(self, l1111lll11_opy_="0"):
        self.l1111lll11_opy_ = l1111lll11_opy_
    def l11ll11111l_opy_(self, l11lllll1l_opy_="no"):
        self.l11lllll1l_opy_ = l11lllll1l_opy_
    def l1llll111lll_opy_(self, level):
        return " " * level + "time : beats<{}> / beat-type<{}> symbol<{}>\n".format(self.l1l1l11111_opy_, self.l1111lll11_opy_, self.l11lllll1l_opy_)
class l11l1l1l1l1_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "transpose"
        self.l11lll111l_opy_ = 0
        self.l111111111_opy_ = 0
        self.l1lll1llll1_opy_ = 0
        self.l1111l11l1_opy_ = False
        self.l1lllllll1l_opy_ = ""
    def l11lll1llll_opy_(self, l11lll111l_opy_):
        self.l11lll111l_opy_ = int(l11lll111l_opy_)
    def l111ll1l11l_opy_(self, l111111111_opy_):
        self.l111111111_opy_ = int(l111111111_opy_)
    def l111l1ll1l1_opy_(self, l1lll1llll1_opy_):
        self.l1lll1llll1_opy_ = int(l1lll1llll1_opy_)
    def l1l1l1111l1_opy_(self, l1111l11l1_opy_):
        self.l1111l11l1_opy_ = l1111l11l1_opy_
    def l1111l11111_opy_(self, l1lllllll1l_opy_):
        self.l1lllllll1l_opy_ = l1lllllll1l_opy_
    def l1llll111lll_opy_(self, level):
        return " " * level + "transpose : diatonic<{}> chromatic<{}> octave-change<{}> double<{}> double-above<{}>\n".format(self.l11lll111l_opy_, self.l111111111_opy_, self.l1lll1llll1_opy_, self.l1111l11l1_opy_, self.l1lllllll1l_opy_)
class l1l111l11l1_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "clef"
        self.sign = "no"
        self.line = "no"
        self.l1lll1l11l11_opy_ = 1
        self.l1lllll1111_opy_ = "no"
        self.l1lllll1ll1_opy_ = "no"
    def l1111l1ll1l_opy_(self, sign="no"):
        self.sign = sign
    def l11l1l11l11_opy_(self, line="no"):
        self.line = line
    def l1l1l11ll11_opy_(self, l1lll1l11l11_opy_):
        self.l1lll1l11l11_opy_ = int(l1lll1l11l11_opy_)
    def l111lll11ll_opy_(self, l1lllll1111_opy_):
        self.l1lllll1111_opy_ = l1lllll1111_opy_
    def l111lll111l_opy_(self, l1lllll1ll1_opy_):
        self.l1lllll1ll1_opy_ = l1lllll1ll1_opy_
    def l1llll111lll_opy_(self, level):
        return " " * level + "clef number<{}> sign<{}> line<{}> clef-octave-change<{}> braille-clef<{}>\n".format(self.l1lll1l11l11_opy_, self.sign, self.line, self.l1lllll1111_opy_, self.l1lllll1ll1_opy_)
class l11llll11ll_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "metronome"
        self.l11111l111_opy_ = "no"
        self.l1l11lllll_opy_ = False
        self.l111111ll1_opy_ = "no"
        self.l1lll1ll1111_opy_ = "no"
        self.l1lll1llllll_opy_ = 1
    def l11l11ll111_opy_(self, l11111l111_opy_="no"):
        self.l11111l111_opy_ = l11111l111_opy_
    def l1ll11l111l_opy_(self, l1l11lllll_opy_=False):
        self.l1l11lllll_opy_ = l1l11lllll_opy_
    def l1ll1111l1l_opy_(self, l111111ll1_opy_="no"):
        self.l111111ll1_opy_ = l111111ll1_opy_
    def l1l1ll111ll_opy_(self, l1lll1ll1111_opy_="missing"):
        self.l1lll1ll1111_opy_ = l1lll1ll1111_opy_
    def l1ll111l1ll_opy_(self, l1lll1llllll_opy_):
        self.l1lll1llllll_opy_ = int(l1lll1llllll_opy_)
    def l1llll111lll_opy_(self, level):
        return " " * level + "metronome : beat-unit<{}> beat-unit-dot<{}> per minute<{}> parenthesis<{}> current_voice<{}>\n".format(self.l11111l111_opy_, self.l1l11lllll_opy_, self.l111111ll1_opy_, self.l1lll1ll1111_opy_, self.l1lll1llllll_opy_)
class l1l1lll1111_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "divisions"
        self.l111l1111l_opy_ = 0
    def l11lllll1ll_opy_(self, l111l1111l_opy_=0):
        self.l111l1111l_opy_ = int(l111l1111l_opy_)
    def l1llll111lll_opy_(self, level):
        return " " * level + "divisions<{}>\n".format(self.l111l1111l_opy_)
class l11l1ll11l1_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "staves"
        self.l1111111ll_opy_ = "no"
    def l11l1l11lll_opy_(self, l1111111ll_opy_="no"):
        self.l1111111ll_opy_ = l1111111ll_opy_
    def l1llll111lll_opy_(self, level):
        return " " * level + "staves<{}>\n".format(self.l1111111ll_opy_)
class l11l1llll1l_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "dynamics"
        self.l1l11l1ll1_opy_ = "no"
    def l11ll1111ll_opy_(self, l1l11l1ll1_opy_):
        self.l1l11l1ll1_opy_ = l1l11l1ll1_opy_
    def l1llll111lll_opy_(self, level):
        return " " * level + "dynamicss<{}>\n".format(self.l1l11l1ll1_opy_)
class l1ll11l1lll_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "pedal"
        self.l111l1lllll_opy_ = False
        self.l1l11l1l11_opy_ = "no"
    def l1l11llll1l_opy_(self, l111l1lllll_opy_):
        self.l111l1lllll_opy_ = l111l1lllll_opy_
    def l1111l111ll_opy_(self, l1l11l1l11_opy_):
        self.l1l11l1l11_opy_ = l1l11l1l11_opy_
    def l1llll111lll_opy_(self, level):
        return " " * level + "pedal<{}> pedal_type<{}>\n".format(self.l111l1lllll_opy_, self.l1l11l1l11_opy_)
class l11ll1111l1_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "wedge"
        self.l1111l1l111_opy_ = False
        self.l11ll11ll1_opy_ = "no"
    def l1l1llll11l_opy_(self, l1111l1l111_opy_):
        self.l1111l1l111_opy_ = l1111l1l111_opy_
    def l1l1lll11l1_opy_(self, l11ll11ll1_opy_):
        self.l11ll11ll1_opy_ = l11ll11ll1_opy_
    def l1llll111lll_opy_(self, level):
        return " " * level + "wedge<{}> wedge_type<{}>\n".format(self.l1111l1l111_opy_, self.l11ll11ll1_opy_)
class l1l1l111l11_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "sound"
        self.l1l11l1ll1l_opy_ = False
        self.l11111l1ll_opy_ = "no"
        self.l11l1lll1l_opy_ = "no"
    def l1111ll1111_opy_(self, l1l11l1ll1l_opy_):
        self.l1l11l1ll1l_opy_ = l1l11l1ll1l_opy_
    def l111llll111_opy_(self, l11111l1ll_opy_):
        self.l11111l1ll_opy_ = l11111l1ll_opy_
    def l11l1l1l111_opy_(self, l11l1lll1l_opy_):
        self.l11l1lll1l_opy_ = l11l1lll1l_opy_
    def l1llll111lll_opy_(self, level):
        return " " * level +\
               "sound<{}> sound_tempo<{}> sound_dynamics<{}>\n".format(self.l1l11l1ll1l_opy_, self.l11111l1ll_opy_, self.l11l1lll1l_opy_)
class l11ll11l1l1_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "direction"
        self.l1lll1111l1_opy_ = list()
        self.l111lll11l_opy_ = "no"
        self.l11111ll11_opy_ = 1
        self.l1lll1llllll_opy_ = 1
    def l1111l1ll11_opy_(self, l111lll11l_opy_):
        self.l111lll11l_opy_ = l111lll11l_opy_
    def l1l1l1ll11l_opy_(self, l11111ll11_opy_="1"):
        self.l11111ll11_opy_ = int(l11111ll11_opy_)
    def l1ll111l1ll_opy_(self, l1lll1llllll_opy_):
        self.l1lll1llllll_opy_ = int(l1lll1llllll_opy_)
    def l1l11l1llll_opy_(self, l1llll11111l_opy_):
        self.l1lll1111l1_opy_.append(l1llll11111l_opy_)
    def l1llll111lll_opy_(self, level):
        text = " " * level + "direction : placement<{}> staff<{}>, self.current_voice<{}>\n".format(self.l111lll11l_opy_, self.l11111ll11_opy_, self.l1lll1llllll_opy_)
        for event in self.l1lll1111l1_opy_:
            text += event.l1llll111lll_opy_(level + 1)
        return text
class l11ll1l1111_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "words"
        self.words = "no"
        self.l11111ll11_opy_ = 1
    def l1ll1111111_opy_(self, words="no"):
        self.words = words
    def l1l1l1ll11l_opy_(self, l11111ll11_opy_=1):
        self.l11111ll11_opy_ = l11111ll11_opy_
    def l1llll111lll_opy_(self, level):
        return " " * level + "words<{}> staff<{}\n".format(self.words, self.l11111ll11_opy_)
class l111l111l11_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "print"
        self.l1111l11ll_opy_ = "no"
        self.l1llll1l1l1l_opy_ = "no"
    def l1l1ll1llll_opy_(self, l1111l11ll_opy_="no"):
        self.l1111l11ll_opy_ = l1111l11ll_opy_
    def l1l11l1lll1_opy_(self, l1llll1l1l1l_opy_="no"):
        self.l1llll1l1l1l_opy_ = l1llll1l1l1l_opy_
    def l1llll111lll_opy_(self, level):
        return " " * level + "new-system<{}> staff-layout_number<{}>\n".format(self.l1111l11ll_opy_, self.l1llll1l1l1l_opy_)
class l1l1l1l111l_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "barline"
        self.location = "no"
        self.l11ll1lll1_opy_ = "no"
        self.l1l111l1ll_opy_ = "no"
        self.l1lll1ll111l_opy_ = False
        self.l1llll1111l1_opy_ = "no"
        self.l1llll11ll11_opy_ = "no"
        self.l1lll1llllll_opy_ = 1
    def l11l1lll1ll_opy_(self, location):
        self.location = location
    def l1111lll11l_opy_(self, l11ll1lll1_opy_):
        self.l11ll1lll1_opy_ = l11ll1lll1_opy_
    def l1l1l1llll1_opy_(self, l1l111l1ll_opy_):
        self.l1l111l1ll_opy_ = l1l111l1ll_opy_
    def l1l11l1l1l1_opy_(self, l1lll1ll111l_opy_):
        self.l1lll1ll111l_opy_ = l1lll1ll111l_opy_
    def l11111lllll_opy_(self, l1llll1111l1_opy_):
        self.l1llll1111l1_opy_ = l1llll1111l1_opy_
    def l11ll1llll1_opy_(self, l1llll11ll11_opy_):
        self.l1llll11ll11_opy_ = l1llll11ll11_opy_
    def l1ll111l1ll_opy_(self, l1lll1llllll_opy_):
        self.l1lll1llllll_opy_ = int(l1lll1llllll_opy_)
    def l1llll111lll_opy_(self, level):
        return " " * level + "barline : location<{}> bar-style<{}> repeat<{}> ending<{}> ending_number<{}> ending_type<{}> current_voice<{}>\n".format(self.location, self.l11ll1lll1_opy_, self.l1l111l1ll_opy_, self.l1lll1ll111l_opy_, self.l1llll1111l1_opy_, self.l1llll11ll11_opy_, self.l1lll1llllll_opy_)
class l111l1ll11l_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "attributes"
        self.l11l111ll1_opy_ = list()
        self.l1lll1llllll_opy_ = 1
        self.l11111ll11_opy_ = 1
        self.l1111111ll_opy_ = 1
    def l1ll111l1ll_opy_(self, l1lll1llllll_opy_):
        self.l1lll1llllll_opy_ = int(l1lll1llllll_opy_)
    def l1l1l1ll11l_opy_(self, l11111ll11_opy_):
        self.l11111ll11_opy_ = int(l11111ll11_opy_)
    def l11l1l11lll_opy_(self, l1111111ll_opy_):
        self.l1111111ll_opy_ = int(l1111111ll_opy_)
    def l1l11l1llll_opy_(self, l1llll11111l_opy_):
        self.l11l111ll1_opy_.append(l1llll11111l_opy_)
    def l1llll111lll_opy_(self, level):
        text = " " * level + "Attributes : staff<{}> staves<{}> current_voice<{}>\n".format(self.l11111ll11_opy_, self.l1111111ll_opy_, self.l1lll1llllll_opy_)
        for event in self.l11l111ll1_opy_:
            text += event.l1llll111lll_opy_(level + 1)
        return text
class l11ll11ll11_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "measure-style"
        self.l1lll1l111ll_opy_ = "no"
        self.l1llll1111ll_opy_ = "no"
        self.l1l1ll1lll1_opy_ = "no"
    def l1l1111l111_opy_(self, l1lll1l111ll_opy_):
        self.l1lll1l111ll_opy_ = l1lll1l111ll_opy_
    def l11l1ll1l1l_opy_(self, l1llll1111ll_opy_):
        self.l1llll1111ll_opy_ = l1llll1111ll_opy_
    def l1lll1l1llll_opy_(self, l1l1ll1lll1_opy_):
        self.l1l1ll1lll1_opy_ = l1l1ll1lll1_opy_
    def l1llll111lll_opy_(self, level):
        return " " * level + "Measure-style : multiple-rest<{}> measurerepeat<{}> repeat-type<{}>\n".format(self.l1lll1l111ll_opy_, self.l1llll1111ll_opy_, self.l1l1ll1lll1_opy_)
class l111l11llll_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "karaoke"
        self.l111l1l11l_opy_ = "no"
    def l111ll11ll1_opy_(self, l111l1l11l_opy_="no"):
        self.l111l1l11l_opy_ = l111l1l11l_opy_
    def l1llll111lll_opy_(self, level):
        return " " * level + "karaoke<{}>\n".format(self.l111l1l11l_opy_)
class l1l1l1l1l1l_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.l111l11lll_opy_ = list()
        self.l1lll111l11_opy_ = 0
        self.l1lll1l1l1ll_opy_ = 0
        self.l1llll11lll1_opy_ = False
    def l1ll111l111_opy_(self, l1lll111l11_opy_):
        self.l1lll111l11_opy_ = int(l1lll111l11_opy_)
    def l1llll11l1l1_opy_(self, l1lll1l1l1ll_opy_):
        self.l1lll1l1l1ll_opy_ = l1lll1l1l1ll_opy_
    def l1lll1l1ll11_opy_(self, l1llll11lll1_opy_):
        self.l1llll11lll1_opy_ = l1llll11lll1_opy_
    def l1l11l1llll_opy_(self, l1llll11111l_opy_):
        self.l111l11lll_opy_.append(l1llll11111l_opy_)
    def l1llll111lll_opy_(self, level):
        text = " " * level + "Measure<{}> duration<{}> is_backup<{}>\n".format(self.l1lll111l11_opy_, self.l1lll1l1l1ll_opy_, self.l1llll11lll1_opy_)
        for event in self.l111l11lll_opy_:
            text += event.l1llll111lll_opy_(level + 1)
        return text
class l1l11ll1l11_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "part"
        self.l11l1l1ll1_opy_ = list()
        self.l111l1l1ll_opy_ = "no"
        self.l111lll1ll_opy_ = "no"
        self.l11111ll1l_opy_ = "no"
    def l1l11l11l11_opy_(self, l111l1l1ll_opy_):
        self.l111l1l1ll_opy_ = l111l1l1ll_opy_
    def l11lll1lll1_opy_(self, l111lll1ll_opy_):
        self.l111lll1ll_opy_ = l111lll1ll_opy_
    def l11lll1ll1l_opy_(self, l11111ll1l_opy_):
        self.l11111ll1l_opy_ = l11111ll1l_opy_
    def l11l1l11111_opy_(self, l1llll111l1l_opy_):
        self.l11l1l1ll1_opy_.append(l1llll111l1l_opy_)
    def l1llll111lll_opy_(self, level):
        text = " " * level + "Part id<{}> part-name<{}> part-abbreviation<{}>\n".format(self.l111l1l1ll_opy_, self.l111lll1ll_opy_, self.l11111ll1l_opy_)
        for l111111l1l_opy_ in self.l11l1l1ll1_opy_:
            text += l111111l1l_opy_.l1llll111lll_opy_(level + 1)
        return text
class l1l1l1ll111_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "credit"
        self.l1llll1ll11_opy_ = "no"
        self.l111lll111_opy_ = "no"
    def l111ll1llll_opy_(self, l111lll111_opy_="no"):
        self.l111lll111_opy_ = l111lll111_opy_
    def l1l1l11l11l_opy_(self, l1llll1ll11_opy_="no"):
        if self.l1llll1ll11_opy_ == "no":
            self.l1llll1ll11_opy_ = l1llll1ll11_opy_
        else:
            self.l1llll1ll11_opy_ += " " + l1llll1ll11_opy_
    def l1llll111lll_opy_(self, level):
        return " " * level + "credit : credit-type<{}> credit-words<{}>\n".format(self.l111lll111_opy_, self.l1llll1ll11_opy_)
class l1l11ll1111_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "work"
        self.l1lll1lll1ll_opy_ = "no"
        self.l1llll11l11l_opy_ = "no"
    def l1l1l11lll1_opy_(self, l1lll1lll1ll_opy_="no"):
        self.l1lll1lll1ll_opy_ = l1lll1lll1ll_opy_
    def l11ll1lllll_opy_(self, l1llll11l11l_opy_="no"):
        self.l1llll11l11l_opy_ = l1llll11l11l_opy_
    def l1llll111lll_opy_(self, level):
        return " " * level + "work : work-number<{}> work-title\n".format(self.l1lll1lll1ll_opy_, self.l1llll11l11l_opy_)
class l1l11lll11l_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "score-part"
        self.l111l1l1ll_opy_ = "no"
        self.l111lll1ll_opy_ = "no"
        self.l11111ll1l_opy_ = "no"
        self.l111ll1111_opy_ = "no"
        self.l1lllll111l_opy_ = "no"
        self.l1l11l11ll_opy_ = "no"
        self.l11l11l111_opy_ = "no"
        self.l111ll1ll1_opy_ = "no"
        self.l111ll11ll_opy_ = "no"
        self.l11ll11l11_opy_ = "no"
        self.l1lllll1lll_opy_ = "no"
        self.l1111ll1ll_opy_ = "no"
        self.l1lll111lll_opy_ = "0"
    def l1l11l11l11_opy_(self, l111l1l1ll_opy_="no"):
        self.l111l1l1ll_opy_ = l111l1l1ll_opy_
    def l11lll1lll1_opy_(self, l111lll1ll_opy_):
        self.l111lll1ll_opy_ = l111lll1ll_opy_
    def l11lll1ll1l_opy_(self, l11111ll1l_opy_):
        self.l11111ll1l_opy_ = l11111ll1l_opy_
    def l11ll111ll1_opy_(self, l111ll1111_opy_="no"):
        self.l111ll1111_opy_ = l111ll1111_opy_
    def l111lll1ll1_opy_(self, l1lllll111l_opy_="no"):
        self.l1lllll111l_opy_ = l1lllll111l_opy_
    def l11lll1l1ll_opy_(self, l1l11l11ll_opy_="no"):
        self.l1l11l11ll_opy_ = l1l11l11ll_opy_
    def l111l1ll1ll_opy_(self, l11l11l111_opy_="no"):
        self.l11l11l111_opy_ = l11l11l111_opy_
    def l11lllllll1_opy_(self, l111ll1ll1_opy_="no"):
        self.l111ll1ll1_opy_ = l111ll1ll1_opy_
    def l111l1llll1_opy_(self, l111ll11ll_opy_="no"):
        self.l111ll11ll_opy_ = l111ll11ll_opy_
    def l11lll111ll_opy_(self, l11ll11l11_opy_="no"):
        self.l11ll11l11_opy_ = l11ll11l11_opy_
    def l11lll1ll11_opy_(self, l1lllll1lll_opy_="no"):
        self.l1lllll1lll_opy_ = l1lllll1lll_opy_
    def l11l1l1l11l_opy_(self, l1111ll1ll_opy_="no"):
        self.l1111ll1ll_opy_ = l1111ll1ll_opy_
    def l11l111l1ll_opy_(self, l1lll111lll_opy_):
        self.l1lll111lll_opy_ = l1lll111lll_opy_
    def l1llll111lll_opy_(self, level):
        return " " * level + "part id<{}> part-name<{}> part-abbreviation<{}> score-instrument<{}> instrument-name<{}> midi-device-id<{}> midi-device-port<{}> midi-instrument-id<{}> midi-channel<{}> midi-program<{}> midi-volume<{}> midi-pan<{}> ascending-chords<{}>\n".format(self.l111l1l1ll_opy_, self.l111lll1ll_opy_, self.l11111ll1l_opy_, self.l111ll1111_opy_, self.l1lllll111l_opy_, self.l1l11l11ll_opy_, self.l11l11l111_opy_, self.l111ll1ll1_opy_, self.l111ll11ll_opy_, self.l11ll11l11_opy_, self.l1lllll1lll_opy_, self.l1111ll1ll_opy_, self.l1lll111lll_opy_)
class l1l1ll1111l_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "part-list"
        self.l111l1l1l1_opy_ = list()
    def l1111lll111_opy_(self, l1lll1l1l1l1_opy_="no"):
        self.l111l1l1l1_opy_.append(l1lll1l1l1l1_opy_)
    def l1llll111lll_opy_(self, level):
        text = " " * level + "part-list\n"
        for part in self.l111l1l1l1_opy_:
            text += part.l1llll111lll_opy_(level + 1)
        return text
class l111lll1l1l_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "global-key"
        self.l1lll1l1l11_opy_ = 100
        self.mode = "no"
    def l11ll1ll111_opy_(self, l1lll1l1l11_opy_=100):
        self.l1lll1l1l11_opy_ = int(l1lll1l1l11_opy_)
    def l111l11l111_opy_(self, mode="no"):
        self.mode = mode
    def l1llll111lll_opy_(self, level):
        return " " * level + "key : fifths<{}> mode<{}>\n".format(self.l1lll1l1l11_opy_, self.mode)
class l1111l111l1_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "global-time"
        self.l1l1l11111_opy_ = "4"
        self.l1111lll11_opy_ = "4"
        self.l11lllll1l_opy_ = "no"
    def l1111ll1l11_opy_(self, l1l1l11111_opy_="0"):
        self.l1l1l11111_opy_ = l1l1l11111_opy_
    def l1l1ll111l1_opy_(self, l1111lll11_opy_="0"):
        self.l1111lll11_opy_ = l1111lll11_opy_
    def l11ll11111l_opy_(self, l11lllll1l_opy_="no"):
        self.l11lllll1l_opy_ = l11lllll1l_opy_
    def l1llll111lll_opy_(self, level):
        return " " * level + "time : beats<{}> / beat-type<{}> symbol<{}>\n".format(self.l1l1l11111_opy_, self.l1111lll11_opy_, self.l11lllll1l_opy_)
class l1l11ll11l1_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.t = "braille-global"
        self.l11l1l1lll_opy_ = list()
    def l1l11l1llll_opy_(self, l1llll11111l_opy_):
        self.l11l1l1lll_opy_.append(l1llll11111l_opy_)
    def l1llll111lll_opy_(self, level):
        text = " " * level + "braille-global\n"
        for element in self.l11l1l1lll_opy_:
            text += element.l1llll111lll_opy_(level + 1)
        return text
class l111111lll1_opy_(l1lll1l1l11l_opy_):
    def __init__(self):
        l1lll1l1l11l_opy_.__init__(self)
        self.l1lll1l111l_opy_ = list()
    def l1l11l1llll_opy_(self, l1llll11111l_opy_):
        self.l1lll1l111l_opy_.append(l1llll11111l_opy_)
    def l1llll111lll_opy_(self, level):
        text = " " * level + "Score\n"
        for element in self.l1lll1l111l_opy_:
            text += element.l1llll111lll_opy_(level + 1)
        return text