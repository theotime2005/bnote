"""
Copyright (c)2021 eurobraille
This software is the proprietary of eurobraille and may not be copied,
distributed, published,or disclosed without express prior written permission.
"""


class l1ll1ll11l1_opy_:
    l1ll1ll1lll_opy_ = True
    l1lll11111l_opy_ = True
